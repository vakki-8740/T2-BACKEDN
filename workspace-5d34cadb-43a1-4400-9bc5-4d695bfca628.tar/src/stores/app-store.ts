"use client";

import { create } from "zustand";

export type ViewKey =
  | "dashboard"
  | "projects"
  | "project"
  | "security"
  | "logs"
  | "settings";

type AppState = {
  view: ViewKey;
  selectedProjectSlug: string | null;
  csrf: string | null;
  setView: (v: ViewKey) => void;
  openProject: (slug: string) => void;
  setSelectedProjectSlug: (slug: string | null) => void;
  setCsrf: (token: string | null) => void;
  clearCsrf: () => void;
};

export const useAppStore = create<AppState>((set) => ({
  view: "dashboard",
  selectedProjectSlug: null,
  csrf: null,
  setView: (v) => set({ view: v }),
  openProject: (slug) => set({ view: "project", selectedProjectSlug: slug }),
  setSelectedProjectSlug: (slug) => set({ selectedProjectSlug: slug }),
  setCsrf: (token) => set({ csrf: token }),
  clearCsrf: () => set({ csrf: null }),
}));
