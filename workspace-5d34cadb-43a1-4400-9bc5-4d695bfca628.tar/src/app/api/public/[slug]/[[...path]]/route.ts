import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import bcrypt from 'bcryptjs'
import { checkProjectRateLimit, gcRateLimitBuckets } from '@/lib/rate-limit'
import { logApiRequest } from '@/lib/logger'
import { getClientIp } from '@/lib/auth'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

type Ctx = { params: Promise<{ slug: string; path?: string[] }> }

function apiFail(message: string, status: number) {
  return NextResponse.json({ success: false, message }, { status })
}

export async function GET(req: NextRequest, ctx: Ctx) {
  return handle(req, ctx, 'GET')
}
export async function POST(req: NextRequest, ctx: Ctx) {
  return handle(req, ctx, 'POST')
}
export async function PUT(req: NextRequest, ctx: Ctx) {
  return handle(req, ctx, 'PUT')
}
export async function PATCH(req: NextRequest, ctx: Ctx) {
  return handle(req, ctx, 'PATCH')
}
export async function DELETE(req: NextRequest, ctx: Ctx) {
  return handle(req, ctx, 'DELETE')
}

async function handle(req: NextRequest, ctx: Ctx, method: string) {
  const start = Date.now()
  const { slug, path } = await ctx.params
  const ip = getClientIp(req)
  const project = await db.project.findUnique({ where: { slug } })
  if (!project) return apiFail('Project not found', 404)

  if (project.status === 'DISABLED') {
    return apiFail('Project is currently disabled.', 503)
  }
  if (project.status === 'MAINTENANCE') {
    return apiFail('Project is in maintenance mode.', 503)
  }
  if (!project.apiEnabled) {
    return apiFail('API is disabled for this project.', 403)
  }

  if (project.apiKeyHash) {
    const auth = req.headers.get('authorization') ?? ''
    const m = /^Bearer\s+(.+)$/i.exec(auth)
    if (!m) return apiFail('Missing API key. Provide Authorization: Bearer <key>.', 401)
    const ok = await bcrypt.compare(m[1]!, project.apiKeyHash)
    if (!ok) return apiFail('Invalid API key.', 401)
  }

  await gcRateLimitBuckets().catch(() => {})
  const rl = await checkProjectRateLimit(project.id, project.rateLimit)
  if (!rl.allowed) {
    return NextResponse.json(
      { success: false, message: 'Rate limit exceeded.', limit: rl.limit },
      { status: 429, headers: { 'Retry-After': String(Math.ceil(rl.resetInMs / 1000)) } },
    )
  }

  const segments = path ?? []
  const endpoint = '/' + segments.join('/')

  try {
    if (segments.length === 0) {
      const resp = NextResponse.json({
        success: true,
        data: {
          name: project.name,
          slug: project.slug,
          version: project.version,
          time: new Date().toISOString(),
        },
      })
      await logApiRequest({ projectId: project.id, method, endpoint, status: 200, ip, responseMs: Date.now() - start })
      return resp
    }
    if (segments[0] === 'collections') {
      const groups = await db.projectResource.groupBy({
        by: ['collection'],
        where: { projectId: project.id },
        _count: { _all: true },
      })
      await logApiRequest({ projectId: project.id, method, endpoint, status: 200, ip, responseMs: Date.now() - start })
      return NextResponse.json({
        success: true,
        data: groups.map((g) => ({ collection: g.collection, count: g._count._all })),
      })
    }
    if (segments[0] === 'resources') {
      if (method === 'GET' && segments.length === 1) {
        const collection = req.nextUrl.searchParams.get('collection') ?? 'default'
        const rows = await db.projectResource.findMany({
          where: { projectId: project.id, collection },
          orderBy: { createdAt: 'asc' },
        })
        await logApiRequest({ projectId: project.id, method, endpoint, status: 200, ip, responseMs: Date.now() - start })
        return NextResponse.json({
          success: true,
          data: rows.map((r) => ({ id: r.id, key: r.key, value: safeJson(r.value), createdAt: r.createdAt, updatedAt: r.updatedAt })),
        })
      }
      if (method === 'POST' && segments.length === 1) {
        const json = await req.json().catch(() => null)
        if (!json) return apiFail('Invalid JSON body', 400)
        const collection = (json.collection as string) || 'default'
        const key = json.key as string | undefined
        const value = json.value
        if (!key) return apiFail('key is required', 400)
        const exists = await db.projectResource.findUnique({
          where: { projectId_collection_key: { projectId: project.id, collection, key } },
        })
        if (exists) return apiFail('Resource with this key already exists', 409)
        const r = await db.projectResource.create({
          data: { projectId: project.id, collection, key, value: typeof value === 'string' ? value : JSON.stringify(value) },
        })
        await logApiRequest({ projectId: project.id, method, endpoint, status: 201, ip, responseMs: Date.now() - start })
        return NextResponse.json({ success: true, data: { id: r.id, key: r.key, value: safeJson(r.value) } }, { status: 201 })
      }
      if (segments.length === 2) {
        const id = segments[1]!
        const r = await db.projectResource.findUnique({ where: { id } })
        if (!r || r.projectId !== project.id) return apiFail('Resource not found', 404)
        if (method === 'GET') {
          await logApiRequest({ projectId: project.id, method, endpoint, status: 200, ip, responseMs: Date.now() - start })
          return NextResponse.json({ success: true, data: { id: r.id, key: r.key, value: safeJson(r.value), createdAt: r.createdAt, updatedAt: r.updatedAt } })
        }
        if (method === 'PATCH') {
          const json = await req.json().catch(() => null)
          if (!json || json.value === undefined) return apiFail('value is required', 400)
          const updated = await db.projectResource.update({
            where: { id },
            data: { value: typeof json.value === 'string' ? json.value : JSON.stringify(json.value) },
          })
          await logApiRequest({ projectId: project.id, method, endpoint, status: 200, ip, responseMs: Date.now() - start })
          return NextResponse.json({ success: true, data: { id: updated.id, key: updated.key, value: safeJson(updated.value) } })
        }
        if (method === 'DELETE') {
          await db.projectResource.delete({ where: { id } })
          await logApiRequest({ projectId: project.id, method, endpoint, status: 200, ip, responseMs: Date.now() - start })
          return NextResponse.json({ success: true, data: { deleted: true } })
        }
      }
    }
    await logApiRequest({ projectId: project.id, method, endpoint, status: 404, ip, responseMs: Date.now() - start })
    return apiFail('Endpoint not found', 404)
  } catch (e) {
    console.error('[public api]', e)
    await logApiRequest({ projectId: project.id, method, endpoint, status: 500, ip, responseMs: Date.now() - start })
    return apiFail('Internal server error', 500)
  }
}

function safeJson(v: string): unknown {
  try {
    return JSON.parse(v)
  } catch {
    return v
  }
}
