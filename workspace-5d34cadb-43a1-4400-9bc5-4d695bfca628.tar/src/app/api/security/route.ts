import { db } from '@/lib/db'
import { getSession, hasAdmin } from '@/lib/auth'
import { apiSuccess, handleApiError, apiError } from '@/lib/api-utils'
import { ensureStorageDirs } from '@/lib/storage'
import { promises as fs } from 'node:fs'
import path from 'node:path'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const [admin, totalProjects, apiEnabledProjects, recentSecurityLogs, backupsCount] = await Promise.all([
      db.admin.findFirst({ select: { id: true, email: true, name: true, role: true, lastLoginAt: true, createdAt: true } }),
      db.project.count(),
      db.project.count({ where: { apiEnabled: true } }),
      db.systemLog.findMany({ where: { category: 'security' }, orderBy: { createdAt: 'desc' }, take: 10 }),
      db.backup.count(),
    ])
    const phpVersion = 'Next.js ' + (process.env.NEXT_VERSION ?? '16.x')
    const env = {
      runtime: 'Node.js ' + process.version,
      framework: phpVersion,
      database: 'SQLite (Prisma)',
      nodeEnv: process.env.NODE_ENV ?? 'development',
    }
    // writable dirs check
    await ensureStorageDirs()
    const storageDir = path.resolve(process.cwd(), 'storage')
    let writable = false
    try {
      const f = path.join(storageDir, '.wtest')
      await fs.writeFile(f, 'ok')
      await fs.rm(f, { force: true })
      writable = true
    } catch {
      // not writable
    }
    return apiSuccess({
      adminAuth: {
        enabled: !!admin,
        email: admin?.email ?? null,
        name: admin?.name ?? null,
        lastLoginAt: admin?.lastLoginAt ?? null,
        createdAt: admin?.createdAt ?? null,
      },
      csrfProtection: { enabled: true, note: 'All state-changing admin actions require a per-session CSRF token.' },
      apiAuth: {
        enabledProjects: apiEnabledProjects,
        totalProjects,
        note: 'Each project has its own bcrypt-hashed API key (Authorization: Bearer <key>).',
      },
      rateLimiting: {
        enabled: true,
        defaultPerMinute: Number((await db.setting.findUnique({ where: { key: 'defaultRateLimit' } }))?.value ?? '100'),
        note: 'Per-project, per-minute window counters in SQLite. Documented limitation: not for high-scale production; use Redis for scale.',
      },
      uploadRestrictions: {
        maxUploadMb: Number((await db.setting.findUnique({ where: { key: 'maxUploadMb' } }))?.value ?? '10'),
        allowedMimesDefault: 'image/jpeg,image/png,image/webp,application/pdf,text/plain',
      },
      environment: env,
      storage: { writable, path: storageDir },
      backups: { count: backupsCount },
      recentSecurityEvents: recentSecurityLogs.map((l) => ({
        id: l.id,
        message: l.message,
        createdAt: l.createdAt,
        level: l.level,
      })),
      setupRequired: !(await hasAdmin()),
    })
  } catch (e) {
    return handleApiError(e)
  }
}
