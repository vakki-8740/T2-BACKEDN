"use client";

import * as React from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useAppStore } from "@/stores/app-store";

export class ApiError extends Error {
  status: number;
  body: unknown;
  constructor(message: string, status: number, body?: unknown) {
    super(message);
    this.status = status;
    this.body = body;
  }
}

type MeResponse = {
  authenticated: boolean;
  setupRequired: boolean;
  admin?: { email: string; name: string; role: string; lastLoginAt: string | null } | null;
  csrf?: string;
};

/**
 * Lightweight fetch helper that:
 *  - sends JSON by default
 *  - injects X-PBM-CSRF for non-GET requests
 *  - throws ApiError on `{ success: false }` or non-ok responses
 *  - returns the unwrapped `data` field on success
 */
export async function apiFetch<T = unknown>(
  path: string,
  init: RequestInit & { skipCsrf?: boolean } = {},
): Promise<T> {
  const csrf = useAppStore.getState().csrf;
  const method = (init.method ?? "GET").toUpperCase();
  const isStateChange = method !== "GET" && method !== "HEAD";
  const headers: Record<string, string> = {
    ...(init.headers as Record<string, string> | undefined),
  };
  // FormData should NOT set JSON content-type; let browser set boundary
  const isFormData =
    typeof FormData !== "undefined" && init.body instanceof FormData;
  if (!isFormData && init.body && !headers["Content-Type"]) {
    headers["Content-Type"] = "application/json";
  }
  if (isStateChange && !init.skipCsrf && csrf) {
    headers["X-PBM-CSRF"] = csrf;
  }
  let res: Response;
  try {
    res = await fetch(path, { ...init, headers });
  } catch (e) {
    throw new ApiError(
      (e as Error).message || "Network request failed",
      0,
    );
  }
  let body: unknown = null;
  const ct = res.headers.get("content-type") ?? "";
  if (ct.includes("application/json")) {
    body = await res.json().catch(() => null);
  } else if (!res.ok) {
    body = await res.text().catch(() => null);
  }
  if (!res.ok) {
    const msg =
      (body && typeof body === "object" && "message" in (body as Record<string, unknown>))
        ? String((body as Record<string, unknown>).message)
        : typeof body === "string" && body
          ? body
          : `Request failed (${res.status})`;
    throw new ApiError(msg, res.status, body);
  }
  if (body && typeof body === "object" && "success" in (body as Record<string, unknown>)) {
    const wrapped = body as { success?: boolean; data?: unknown; message?: string };
    if (wrapped.success === false) {
      throw new ApiError(wrapped.message ?? "Request failed", res.status, body);
    }
    return wrapped.data as T;
  }
  return body as T;
}

export function useAuth() {
  const queryClient = useQueryClient();
  const setCsrf = useAppStore((s) => s.setCsrf);
  const clearCsrf = useAppStore((s) => s.clearCsrf);

  const { data, isLoading, isFetching, refetch } = useQuery<MeResponse>({
    queryKey: ["auth", "me"],
    queryFn: async () => {
      const me = await apiFetch<MeResponse>("/api/auth/me");
      if (me.csrf) setCsrf(me.csrf);
      else clearCsrf();
      return me;
    },
    staleTime: 60 * 1000,
    refetchOnMount: true,
  });

  const status: "loading" | "setup" | "login" | "authed" = isLoading
    ? "loading"
    : data?.setupRequired
      ? "setup"
      : data?.authenticated
        ? "authed"
        : "login";

  const refresh = React.useCallback(async () => {
    await queryClient.invalidateQueries({ queryKey: ["auth", "me"] });
    return refetch();
  }, [queryClient, refetch]);

  return { status, me: data ?? null, refetch, refresh };
}

/** Convenience wrapper for invalidation after mutations. */
export function useInvalidate() {
  const queryClient = useQueryClient();
  return React.useCallback(
    (keys: string[] | readonly string[]) =>
      queryClient.invalidateQueries({ queryKey: [...keys] }),
    [queryClient],
  );
}
