import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSession } from '@/lib/auth'
import { apiSuccess, handleApiError, apiError } from '@/lib/api-utils'
import { projectStorageRoot, projectUploadsDir, dirSizeBytes, formatBytes, countFiles } from '@/lib/storage'
import { promises as fs } from 'node:fs'
import path from 'node:path'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(_req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const { slug } = await ctx.params
    const project = await db.project.findUnique({ where: { slug } })
    if (!project) return apiError('Project not found', 404)
    const [storageBytes, uploadsBytes, fileCount, resourceCount, collections] = await Promise.all([
      dirSizeBytes(projectStorageRoot(slug)),
      dirSizeBytes(projectUploadsDir(slug)),
      countFiles(projectUploadsDir(slug)),
      db.projectResource.count({ where: { projectId: project.id } }),
      db.projectResource.groupBy({
        by: ['collection'],
        where: { projectId: project.id },
        _count: { _all: true },
      }),
    ])
    // db file size on disk (best-effort: estimate as project storage bytes)
    let dbModified = ''
    try {
      const st = await fs.stat(path.join(projectStorageRoot(slug), 'config', 'project.json'))
      dbModified = st.mtime.toISOString()
    } catch {
      // ignore
    }
    return apiSuccess({
      database: {
        type: 'SQLite (logical isolation by projectId)',
        storageBytes,
        storage: formatBytes(storageBytes),
        uploadsBytes,
        uploads: formatBytes(uploadsBytes),
        fileCount,
        resourceCount,
        collections: collections.map((c) => ({ name: c.collection, count: c._count._all })),
        lastModified: dbModified,
      },
    })
  } catch (e) {
    return handleApiError(e)
  }
}
