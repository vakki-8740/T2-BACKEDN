import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSession, requireCsrf, getClientIp } from '@/lib/auth'
import { apiSuccess, handleApiError, apiError } from '@/lib/api-utils'
import { buildProjectBackupZip, saveBackupToDisk } from '@/lib/backup'
import { logActivity, logSystem } from '@/lib/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const { slug } = await ctx.params
    const project = await db.project.findUnique({ where: { slug } })
    if (!project) return apiError('Project not found', 404)
    const { buffer, sizeBytes } = await buildProjectBackupZip(project.id, project.slug)
    const filename = await saveBackupToDisk(project.id, project.slug, buffer)
    await db.backup.create({
      data: { projectId: project.id, filename, sizeBytes },
    })
    await logActivity({
      action: 'backup.create',
      projectId: project.id,
      message: `Backup created: ${filename}`,
      ip: getClientIp(req),
    })
    await logSystem({ category: 'backup', message: `Backup created for ${slug}` })
    return new Response(new Uint8Array(buffer), {
      status: 200,
      headers: {
        'Content-Type': 'application/zip',
        'Content-Disposition': `attachment; filename="${filename}"`,
      },
    })
  } catch (e) {
    return handleApiError(e)
  }
}

// list backups for the project
export async function POST(req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const { slug } = await ctx.params
    const project = await db.project.findUnique({ where: { slug } })
    if (!project) return apiError('Project not found', 404)
    const backups = await db.backup.findMany({
      where: { projectId: project.id },
      orderBy: { createdAt: 'desc' },
      take: 20,
    })
    return apiSuccess({ backups })
  } catch (e) {
    return handleApiError(e)
  }
}
