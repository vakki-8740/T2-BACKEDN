import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSession, requireCsrf, getClientIp } from '@/lib/auth'
import { apiSuccess, handleApiError, apiError } from '@/lib/api-utils'
import { logActivity } from '@/lib/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(_req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const { slug } = await ctx.params
    const project = await db.project.findUnique({ where: { slug } })
    if (!project) return apiError('Project not found', 404)
    const settings = await db.projectSetting.findMany({ where: { projectId: project.id } })
    const map: Record<string, string> = {}
    for (const s of settings) map[s.key] = s.value
    return apiSuccess({
      settings: map,
      apiEnabled: project.apiEnabled,
      rateLimit: project.rateLimit,
      status: project.status,
    })
  } catch (e) {
    return handleApiError(e)
  }
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const csrf = req.headers.get('x-pbm-csrf') ?? undefined
    requireCsrf(sess.csrf, csrf)
    const { slug } = await ctx.params
    const project = await db.project.findUnique({ where: { slug } })
    if (!project) return apiError('Project not found', 404)
    const json = (await req.json().catch(() => ({}))) as {
      settings?: Record<string, string>
      apiEnabled?: boolean
      rateLimit?: number
    }
    if (json.settings) {
      for (const [k, v] of Object.entries(json.settings)) {
        await db.projectSetting.upsert({
          where: { projectId_key: { projectId: project.id, key: k } },
          update: { value: v },
          create: { projectId: project.id, key: k, value: v },
        })
      }
    }
    const updated = await db.project.update({
      where: { id: project.id },
      data: {
        apiEnabled: typeof json.apiEnabled === 'boolean' ? json.apiEnabled : undefined,
        rateLimit: typeof json.rateLimit === 'number' ? json.rateLimit : undefined,
      },
    })
    await logActivity({
      action: 'project.settings',
      projectId: project.id,
      message: `Project settings updated for "${updated.name}"`,
      ip: getClientIp(req),
    })
    return apiSuccess({ apiEnabled: updated.apiEnabled, rateLimit: updated.rateLimit })
  } catch (e) {
    return handleApiError(e)
  }
}
