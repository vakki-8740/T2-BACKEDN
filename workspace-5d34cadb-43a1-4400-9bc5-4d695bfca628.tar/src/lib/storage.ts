import path from 'node:path'
import { promises as fs } from 'node:fs'

export const STORAGE_ROOT = path.resolve(process.cwd(), 'storage')
export const PROJECTS_STORAGE = path.join(STORAGE_ROOT, 'projects')
export const BACKUPS_STORAGE = path.join(STORAGE_ROOT, 'backups')

export async function ensureStorageDirs() {
  await fs.mkdir(PROJECTS_STORAGE, { recursive: true })
  await fs.mkdir(BACKUPS_STORAGE, { recursive: true })
}

export function projectStorageRoot(slug: string): string {
  // path is constrained to be inside PROJECTS_STORAGE
  return path.join(PROJECTS_STORAGE, slug)
}

export function projectUploadsDir(slug: string): string {
  return path.join(projectStorageRoot(slug), 'uploads')
}

export function projectBackupDir(slug: string): string {
  return path.join(projectStorageRoot(slug), 'backups')
}

export async function initProjectStorage(slug: string) {
  const base = projectStorageRoot(slug)
  await fs.mkdir(path.join(base, 'uploads'), { recursive: true })
  await fs.mkdir(path.join(base, 'backups'), { recursive: true })
  await fs.mkdir(path.join(base, 'config'), { recursive: true })
  // project config file
  const configPath = path.join(base, 'config', 'project.json')
  await fs.writeFile(
    configPath,
    JSON.stringify({ slug, createdAt: new Date().toISOString(), version: '1.0.0' }, null, 2),
  )
}

export async function removeProjectStorage(slug: string) {
  const base = projectStorageRoot(slug)
  // double-check the base is within PROJECTS_STORAGE (defense in depth)
  const rel = path.relative(PROJECTS_STORAGE, base)
  if (rel.startsWith('..') || path.isAbsolute(rel)) {
    throw new Error('REFUSED_TO_DELETE_OUTSIDE_PROJECT_DIR')
  }
  await fs.rm(base, { recursive: true, force: true })
}

// directory size in bytes
export async function dirSizeBytes(dirPath: string): Promise<number> {
  try {
    const stat = await fs.stat(dirPath)
    if (!stat.isDirectory()) return stat.size
  } catch {
    return 0
  }
  let total = 0
  const stack = [dirPath]
  while (stack.length) {
    const cur = stack.pop()!
    const entries = await fs.readdir(cur, { withFileTypes: true })
    for (const e of entries) {
      const full = path.join(cur, e.name)
      if (e.isDirectory()) stack.push(full)
      else {
        const st = await fs.stat(full).catch(() => null)
        if (st) total += st.size
      }
    }
  }
  return total
}

export async function countFiles(dirPath: string): Promise<number> {
  let count = 0
  try {
    const stat = await fs.stat(dirPath)
    if (!stat.isDirectory()) return 1
  } catch {
    return 0
  }
  const stack = [dirPath]
  while (stack.length) {
    const cur = stack.pop()!
    const entries = await fs.readdir(cur, { withFileTypes: true })
    for (const e of entries) {
      const full = path.join(cur, e.name)
      if (e.isDirectory()) stack.push(full)
      else count += 1
    }
  }
  return count
}

export function formatBytes(bytes: number): string {
  if (!bytes || bytes < 0) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB', 'TB']
  const i = Math.min(units.length - 1, Math.floor(Math.log10(bytes) / 3))
  const v = bytes / Math.pow(1000, i)
  return `${v.toFixed(v < 10 && i > 0 ? 1 : 0)} ${units[i]}`
}
