import { db } from '@/lib/db'

export type ApiLogInput = {
  projectId: string
  method: string
  endpoint: string
  status: number
  ip?: string
  responseMs?: number
}

export async function logApiRequest(input: ApiLogInput) {
  try {
    await db.apiLog.create({ data: input })
    await db.project.update({
      where: { id: input.projectId },
      data: { lastActivity: new Date() },
    })
  } catch {
    // never fail a request because of logging
  }
}

export type ActivityLogInput = {
  action: string
  projectId?: string
  message: string
  ip?: string
  userAgent?: string
}

export async function logActivity(input: ActivityLogInput) {
  try {
    await db.activityLog.create({ data: input })
  } catch {
    // ignore
  }
}

export type SystemLogInput = {
  level?: 'info' | 'warn' | 'error' | 'security'
  category?: 'system' | 'security' | 'backup'
  message: string
  meta?: string
}

export async function logSystem(input: SystemLogInput) {
  try {
    await db.systemLog.create({
      data: {
        level: input.level ?? 'info',
        category: input.category ?? 'system',
        message: input.message,
        meta: input.meta,
      },
    })
  } catch {
    // ignore
  }
}
