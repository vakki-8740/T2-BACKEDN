import { getSession, hasAdmin } from '@/lib/auth'
import { apiSuccess, handleApiError } from '@/lib/api-utils'
import { db } from '@/lib/db'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const setupRequired = !(await hasAdmin())
    const sess = await getSession()
    if (!sess) return apiSuccess({ authenticated: false, setupRequired })
    const admin = await db.admin.findUnique({ where: { id: sess.adminId } })
    return apiSuccess({
      authenticated: true,
      setupRequired,
      admin: admin
        ? { email: admin.email, name: admin.name, role: admin.role, lastLoginAt: admin.lastLoginAt }
        : null,
      csrf: sess.csrf,
    })
  } catch (e) {
    return handleApiError(e)
  }
}
