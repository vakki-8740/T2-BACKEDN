import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSession, requireCsrf, getClientIp } from '@/lib/auth'
import { apiSuccess, handleApiError, apiError } from '@/lib/api-utils'
import { projectUploadsDir } from '@/lib/storage'
import { logActivity } from '@/lib/logger'
import { promises as fs } from 'node:fs'
import path from 'node:path'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ slug: string; fileId: string }> }) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const csrf = req.headers.get('x-pbm-csrf') ?? undefined
    requireCsrf(sess.csrf, csrf)
    const { slug, fileId } = await ctx.params
    const project = await db.project.findUnique({ where: { slug } })
    if (!project) return apiError('Project not found', 404)
    const file = await db.projectFile.findUnique({ where: { id: fileId } })
    if (!file || file.projectId !== project.id) return apiError('File not found', 404)
    const uploadsRoot = projectUploadsDir(slug)
    const full = path.join(uploadsRoot, file.relPath)
    const rel = path.relative(uploadsRoot, full)
    if (rel.startsWith('..') || path.isAbsolute(rel)) return apiError('Path traversal', 400)
    await fs.rm(full, { force: true }).catch(() => {})
    await db.projectFile.delete({ where: { id: file.id } })
    await logActivity({
      action: 'file.delete',
      projectId: project.id,
      message: `Deleted file ${file.originalName}`,
      ip: getClientIp(req),
    })
    return apiSuccess({ deleted: true })
  } catch (e) {
    return handleApiError(e)
  }
}
