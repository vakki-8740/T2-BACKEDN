"use client";

import * as React from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AlertTriangle } from "lucide-react";
import { ApiError, apiFetch } from "@/lib/api-client";
import { toast } from "sonner";

export function DeleteProjectDialog({
  open,
  onOpenChange,
  project,
  onDeleted,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  project: { name: string; slug: string } | null;
  onDeleted: () => void;
}) {
  const [typed, setTyped] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);

  React.useEffect(() => {
    if (!open) setTyped("");
  }, [open]);

  if (!project) return null;
  const expected = project.name;
  const matches = typed === expected;

  async function onDelete(e: React.FormEvent) {
    e.preventDefault();
    if (submitting) return;
    if (!matches) {
      toast.error("Type the project name exactly to confirm");
      return;
    }
    setSubmitting(true);
    try {
      await apiFetch(`/api/projects/${project.slug}`, {
        method: "DELETE",
        body: JSON.stringify({ confirm: typed }),
      });
      toast.success("Project deleted");
      onOpenChange(false);
      onDeleted();
    } catch (err) {
      const msg = err instanceof ApiError ? err.message : "Could not delete project";
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-destructive flex items-center gap-2">
            <AlertTriangle className="size-5" />
            Delete project
          </DialogTitle>
          <DialogDescription>
            This will permanently delete the project <strong>{project.name}</strong>{" "}
            ({project.slug}), including all files, resources, settings and backups.
            This action cannot be undone.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={onDelete} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="delete-confirm">
              Type <span className="font-mono font-semibold">{expected}</span> to confirm
            </Label>
            <Input
              id="delete-confirm"
              value={typed}
              onChange={(e) => setTyped(e.target.value)}
              placeholder={expected}
              autoComplete="off"
              className="font-mono"
            />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="destructive" disabled={!matches || submitting}>
              {submitting ? "Deleting…" : "Delete project"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
