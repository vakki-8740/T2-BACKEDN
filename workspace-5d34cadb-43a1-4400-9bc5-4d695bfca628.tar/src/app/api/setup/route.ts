import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { hasAdmin } from '@/lib/auth'
import { apiError, apiSuccess, handleApiError } from '@/lib/api-utils'
import { logSystem } from '@/lib/logger'
import bcrypt from 'bcryptjs'
import { z } from 'zod'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const body = z.object({
  email: z.string().email(),
  name: z.string().min(1).max(80),
  password: z.string().min(8).max(128),
  systemName: z.string().min(1).max(80).default('Project Backend Manager'),
})

export async function POST(req: NextRequest) {
  try {
    const already = await hasAdmin()
    if (already) {
      return apiError('Setup already completed. Please sign in.', 409)
    }
    const json = await req.json().catch(() => null)
    const parsed = body.safeParse(json)
    if (!parsed.success) {
      return apiError('Invalid input. Email, name and a password (>=8 chars) are required.', 400)
    }
    const { email, name, password, systemName } = parsed.data
    const passwordHash = await bcrypt.hash(password, 12)
    const admin = await db.admin.create({
      data: { email: email.toLowerCase(), name, passwordHash, role: 'owner' },
    })
    await db.setting.upsert({
      where: { key: 'systemName' },
      update: { value: systemName },
      create: { key: 'systemName', value: systemName },
    })
    await db.setting.upsert({
      where: { key: 'maxUploadMb' },
      update: { value: '10' },
      create: { key: 'maxUploadMb', value: '10' },
    })
    await db.setting.upsert({
      where: { key: 'defaultRateLimit' },
      update: { value: '100' },
      create: { key: 'defaultRateLimit', value: '100' },
    })
    await db.setting.upsert({
      where: { key: 'sessionTimeoutMinutes' },
      update: { value: '720' },
      create: { key: 'sessionTimeoutMinutes', value: '720' },
    })
    await logSystem({
      level: 'security',
      category: 'security',
      message: `Admin account created: ${email}`,
    })
    return apiSuccess({ adminId: admin.id, email: admin.email, name: admin.name }, 201)
  } catch (e) {
    return handleApiError(e)
  }
}

export async function GET() {
  try {
    return apiSuccess({ setupRequired: !(await hasAdmin()) })
  } catch (e) {
    return handleApiError(e)
  }
}
