"use client";

import * as React from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { AlertTriangle } from "lucide-react";
import { ApiError, apiFetch } from "@/lib/api-client";
import { toast } from "sonner";
import { slugify } from "@/lib/format";

export type CreateProjectResult = {
  apiKey?: string | null;
  name: string;
  slug: string;
};

export function CreateProjectDialog({
  open,
  onOpenChange,
  defaultRateLimit = 100,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  defaultRateLimit?: number;
  onCreated: (r: CreateProjectResult) => void;
}) {
  const [name, setName] = React.useState("");
  const [slug, setSlug] = React.useState("");
  const [slugTouched, setSlugTouched] = React.useState(false);
  const [description, setDescription] = React.useState("");
  const [generateApiKey, setGenerateApiKey] = React.useState(true);
  const [apiEnabled, setApiEnabled] = React.useState(true);
  const [rateLimit, setRateLimit] = React.useState<number>(defaultRateLimit);
  const [submitting, setSubmitting] = React.useState(false);

  React.useEffect(() => {
    if (!slugTouched) {
      setSlug(slugify(name));
    }
  }, [name, slugTouched]);

  function reset() {
    setName("");
    setSlug("");
    setSlugTouched(false);
    setDescription("");
    setGenerateApiKey(true);
    setApiEnabled(true);
    setRateLimit(defaultRateLimit);
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (submitting) return;
    if (!name || name.length < 2) {
      toast.error("Name must be at least 2 characters");
      return;
    }
    if (!slug || slug.length < 2) {
      toast.error("Slug must be at least 2 characters (letters, numbers, hyphens)");
      return;
    }
    setSubmitting(true);
    try {
      const result = await apiFetch<CreateProjectResult>("/api/projects", {
        method: "POST",
        body: JSON.stringify({
          name,
          slug,
          description,
          generateApiKey,
          apiEnabled,
          rateLimit,
        }),
      });
      toast.success("Project created");
      onCreated(result);
      reset();
      onOpenChange(false);
    } catch (err) {
      const msg = err instanceof ApiError ? err.message : "Could not create project";
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => { onOpenChange(v); if (!v) reset(); }}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Create a new project</DialogTitle>
          <DialogDescription>
            Each project is fully isolated with its own storage, database and API key.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={onSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="pj-name">Project name</Label>
            <Input
              id="pj-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="My Awesome API"
              required
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="pj-slug">Slug</Label>
            <Input
              id="pj-slug"
              value={slug}
              onChange={(e) => {
                setSlugTouched(true);
                setSlug(e.target.value);
              }}
              placeholder="my-awesome-api"
              className="font-mono text-sm"
            />
            <p className="text-[11px] text-muted-foreground">
              Used in the public API URL: <span className="font-mono">/api/public/{slug || "slug"}/</span>
            </p>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="pj-desc">Description</Label>
            <Textarea
              id="pj-desc"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
              placeholder="A short, human-friendly description."
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="pj-rate">Rate limit (per min)</Label>
              <Input
                id="pj-rate"
                type="number"
                min={1}
                max={10000}
                value={rateLimit}
                onChange={(e) => setRateLimit(Number(e.target.value) || 0)}
              />
            </div>
          </div>
          <div className="space-y-2 rounded-md border p-3">
            <label className="flex items-start gap-2 cursor-pointer">
              <Checkbox
                checked={generateApiKey}
                onCheckedChange={(v) => setGenerateApiKey(Boolean(v))}
                id="pj-genkey"
              />
              <div className="space-y-0.5">
                <Label htmlFor="pj-genkey" className="cursor-pointer">Generate API key</Label>
                <p className="text-[11px] text-muted-foreground">
                  Creates a new bcrypt-hashed API key and shows it once.
                </p>
              </div>
            </label>
            <label className="flex items-start gap-2 cursor-pointer">
              <Checkbox
                checked={apiEnabled}
                onCheckedChange={(v) => setApiEnabled(Boolean(v))}
                id="pj-apienabled"
              />
              <div className="space-y-0.5">
                <Label htmlFor="pj-apienabled" className="cursor-pointer">Enable public API</Label>
                <p className="text-[11px] text-muted-foreground">
                  When enabled, requests are accepted with a valid API key.
                </p>
              </div>
            </label>
          </div>
          {generateApiKey && (
            <div className="flex items-start gap-2 rounded-md bg-amber-50 border border-amber-200 p-3 text-amber-800 text-[11px] dark:bg-amber-950/40 dark:border-amber-900 dark:text-amber-200">
              <AlertTriangle className="size-3.5 mt-0.5 shrink-0" />
              <span>
                The API key will be shown once after creation. Copy and store it securely — you will not be able to see it again.
              </span>
            </div>
          )}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={submitting}>
              {submitting ? "Creating…" : "Create project"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
