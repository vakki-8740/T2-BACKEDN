import { db } from '@/lib/db'
import { cookies } from 'next/headers'
import crypto from 'node:crypto'

export const SESSION_COOKIE = 'pbm_session'
const SESSION_TTL = 60 * 60 * 12 // 12 hours
const SECRET = process.env.PBM_SECRET || 'dev-only-change-me-in-production-please'

// In-memory session store (production should use a persistent store).
// NOTE: We attach the Map to globalThis so that multiple Turbopack route-handler
// module graphs (which can each compile their own copy of this lib file in dev)
// share the same session/login-attempt state. Without this, /api/auth/login
// writing to one copy and /api/projects reading from another would cause 401s.
type Session = {
  adminId: string
  email: string
  name: string
  expiresAt: number
  csrf: string
}
const sessions: Map<string, Session> =
  (globalThis as unknown as { __PBM_SESSIONS__?: Map<string, Session> }).__PBM_SESSIONS__ ??
  (((globalThis as unknown as { __PBM_SESSIONS__?: Map<string, Session> }).__PBM_SESSIONS__ =
    new Map<string, Session>()))

function sign(payload: string) {
  return crypto.createHmac('sha256', SECRET).update(payload).digest('hex')
}

export function createSession(admin: { id: string; email: string; name: string }) {
  const csrf = crypto.randomBytes(24).toString('hex')
  const expiresAt = Date.now() + SESSION_TTL * 1000
  const payload = JSON.stringify({ id: admin.id, email: admin.email, name: admin.name, csrf, exp: expiresAt })
  const sig = sign(payload)
  const token = Buffer.from(payload).toString('base64url') + '.' + sig
  sessions.set(token, { adminId: admin.id, email: admin.email, name: admin.name, expiresAt, csrf })
  return { token, expiresAt, csrf }
}

export function destroySession(token: string) {
  sessions.delete(token)
}

export async function getSession(): Promise<Session | null> {
  const store = await cookies()
  const token = store.get(SESSION_COOKIE)?.value
  if (!token) return null
  const sess = sessions.get(token)
  if (!sess) return null
  if (sess.expiresAt < Date.now()) {
    sessions.delete(token)
    return null
  }
  return sess
}

export async function requireAdmin(): Promise<Session> {
  const s = await getSession()
  if (!s) {
    const err = new Error('UNAUTHORIZED')
    ;(err as any).status = 401
    throw err
  }
  return s
}

export function requireCsrf(token: string | undefined, provided: string | undefined) {
  if (!token || !provided) {
    const err = new Error('CSRF_MISSING')
    ;(err as any).status = 403
    throw err
  }
  if (token !== provided) {
    const err = new Error('CSRF_INVALID')
    ;(err as any).status = 403
    throw err
  }
}

export function getSessionTtl() {
  return SESSION_TTL
}

export async function setSessionCookie(token: string, expiresAt: number) {
  const store = await cookies()
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    expires: new Date(expiresAt),
  })
}

export async function clearSessionCookie() {
  const store = await cookies()
  store.delete(SESSION_COOKIE)
}

export async function hasAdmin(): Promise<boolean> {
  const count = await db.admin.count()
  return count > 0
}

// failed-login rate limiting (per IP) — also on globalThis for the same reason.
const loginAttempts: Map<string, { count: number; lockedUntil: number }> =
  (globalThis as unknown as { __PBM_LOGIN_ATTEMPTS__?: Map<string, { count: number; lockedUntil: number }> }).__PBM_LOGIN_ATTEMPTS__ ??
  (((globalThis as unknown as { __PBM_LOGIN_ATTEMPTS__?: Map<string, { count: number; lockedUntil: number }> }).__PBM_LOGIN_ATTEMPTS__ =
    new Map<string, { count: number; lockedUntil: number }>()))
const MAX_LOGIN_ATTEMPTS = 5
const LOCK_WINDOW_MS = 5 * 60 * 1000

export function checkLoginRate(ip: string): { ok: boolean; retryAfterMs: number } {
  const now = Date.now()
  const entry = loginAttempts.get(ip)
  if (entry && entry.lockedUntil > now) {
    return { ok: false, retryAfterMs: entry.lockedUntil - now }
  }
  return { ok: true, retryAfterMs: 0 }
}

export function recordFailedLogin(ip: string) {
  const now = Date.now()
  const entry = loginAttempts.get(ip) ?? { count: 0, lockedUntil: 0 }
  entry.count += 1
  if (entry.count >= MAX_LOGIN_ATTEMPTS) {
    entry.lockedUntil = now + LOCK_WINDOW_MS
    entry.count = 0
  }
  loginAttempts.set(ip, entry)
}

export function resetLoginRate(ip: string) {
  loginAttempts.delete(ip)
}

export function getClientIp(req: Request): string {
  const fwd = req.headers.get('x-forwarded-for')
  if (fwd) return fwd.split(',')[0]!.trim()
  return '127.0.0.1'
}
