import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSession, requireCsrf, getClientIp } from '@/lib/auth'
import { apiSuccess, handleApiError, apiError } from '@/lib/api-utils'
import { projectUploadsDir, dirSizeBytes, formatBytes } from '@/lib/storage'
import { isSafeRelativePath, randomFilename } from '@/lib/security'
import { logActivity } from '@/lib/logger'
import { promises as fs } from 'node:fs'
import path from 'node:path'
import { z } from 'zod'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const { slug } = await ctx.params
    const project = await db.project.findUnique({ where: { slug } })
    if (!project) return apiError('Project not found', 404)
    const subdir = req.nextUrl.searchParams.get('subdir') ?? ''
    const uploadsRoot = projectUploadsDir(slug)
    const target = subdir ? path.join(uploadsRoot, subdir) : uploadsRoot
    const rel = path.relative(uploadsRoot, target)
    if (rel.startsWith('..') || path.isAbsolute(rel)) {
      return apiError('Path traversal detected', 400)
    }
    // load DB rows for this project so we can attach id / originalName / mime
    const allFiles = await db.projectFile.findMany({ where: { projectId: project.id } })
    const byRel: Record<string, { id: string; originalName: string; mime: string }> = {}
    for (const f of allFiles) byRel[f.relPath] = { id: f.id, originalName: f.originalName, mime: f.mime }
    let entries: {
      name: string
      type: 'file' | 'dir'
      size: number
      modified: string
      fileId?: string
      originalName?: string
      mime?: string
    }[] = []
    try {
      const items = await fs.readdir(target, { withFileTypes: true })
      const baseRel = subdir ? subdir : ''
      entries = await Promise.all(
        items.map(async (e) => {
          const full = path.join(target, e.name)
          if (e.isDirectory()) {
            return { name: e.name, type: 'dir' as const, size: 0, modified: '' }
          }
          const st = await fs.stat(full).catch(() => null)
          const rel = baseRel ? path.posix.join(baseRel, e.name) : e.name
          const dbRow = byRel[rel]
          return {
            name: e.name,
            type: 'file' as const,
            size: st?.size ?? 0,
            modified: st?.mtime.toISOString() ?? '',
            fileId: dbRow?.id,
            originalName: dbRow?.originalName,
            mime: dbRow?.mime,
          }
        }),
      )
      entries.sort((a, b) => (a.type === b.type ? a.name.localeCompare(b.name) : a.type === 'dir' ? -1 : 1))
    } catch {
      // not exist yet
    }
    return apiSuccess({ files: entries, subdir })
  } catch (e) {
    return handleApiError(e)
  }
}

const allowedImageMimes = new Set([
  'image/jpeg', 'image/png', 'image/webp', 'image/gif',
  'application/pdf', 'text/plain', 'application/json',
  'text/csv', 'image/svg+xml',
])

export async function POST(req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const csrf = req.headers.get('x-pbm-csrf') ?? undefined
    requireCsrf(sess.csrf, csrf)
    const { slug } = await ctx.params
    const project = await db.project.findUnique({ where: { slug } })
    if (!project) return apiError('Project not found', 404)
    const form = await req.formData()
    const file = form.get('file') as File | null
    const subdir = (form.get('subdir') as string | null) ?? ''
    if (!file) return apiError('No file uploaded', 400)
    // size check (use global default 10MB if not set)
    const maxUploadMbSetting = await db.projectSetting.findUnique({
      where: { projectId_key: { projectId: project.id, key: 'maxUploadMb' } },
    })
    const maxMb = Number(maxUploadMbSetting?.value ?? '10')
    if (file.size > maxMb * 1024 * 1024) {
      return apiError(`File too large. Max ${maxMb}MB.`, 413)
    }
    const mime = file.type || 'application/octet-stream'
    const allowedSetting = await db.projectSetting.findUnique({
      where: { projectId_key: { projectId: project.id, key: 'allowedMimes' } },
    })
    const allowed = (allowedSetting?.value ?? '').split(',').map((s) => s.trim()).filter(Boolean)
    if (allowed.length && !allowed.includes(mime) && !allowed.includes(file.type)) {
      return apiError(`File type not allowed: ${mime}`, 415)
    }
    if (!allowedImageMimes.has(mime) && !mime.startsWith('image/')) {
      return apiError(`File type not allowed: ${mime}`, 415)
    }
    const safeSub = subdir && isSafeRelativePath(subdir) ? subdir : ''
    const uploadsRoot = projectUploadsDir(slug)
    const targetDir = safeSub ? path.join(uploadsRoot, safeSub) : uploadsRoot
    const rel = path.relative(uploadsRoot, targetDir)
    if (rel.startsWith('..') || path.isAbsolute(rel)) {
      return apiError('Path traversal detected', 400)
    }
    await fs.mkdir(targetDir, { recursive: true })
    const stored = randomFilename(file.name)
    const fullPath = path.join(targetDir, stored)
    const buf = Buffer.from(await file.arrayBuffer())
    await fs.writeFile(fullPath, buf)
    const relPath = safeSub ? path.posix.join(safeSub, stored) : stored
    const record = await db.projectFile.create({
      data: {
        projectId: project.id,
        filename: stored,
        originalName: file.name,
        mime,
        size: file.size,
        relPath,
      },
    })
    await logActivity({
      action: 'file.upload',
      projectId: project.id,
      message: `Uploaded ${file.name} (${formatBytes(file.size)})`,
      ip: getClientIp(req),
    })
    return apiSuccess(
      { id: record.id, filename: stored, originalName: record.originalName, mime, size: file.size, relPath },
      201,
    )
  } catch (e) {
    return handleApiError(e)
  }
}

const postExtra = z.object({
  action: z.enum(['mkdir', 'rename']).optional(),
  name: z.string().min(1).max(120).optional(),
  newName: z.string().min(1).max(120).optional(),
  subdir: z.string().optional(),
})

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const csrf = req.headers.get('x-pbm-csrf') ?? undefined
    requireCsrf(sess.csrf, csrf)
    const { slug } = await ctx.params
    const project = await db.project.findUnique({ where: { slug } })
    if (!project) return apiError('Project not found', 404)
    const json = (await req.json().catch(() => ({}))) as Record<string, unknown>
    const parsed = postExtra.safeParse(json)
    if (!parsed.success) return apiError('Invalid input', 400)
    const uploadsRoot = projectUploadsDir(slug)
    if (parsed.data.action === 'mkdir') {
      const name = parsed.data.name!
      if (!isSafeRelativePath(name) || name.includes('/')) {
        return apiError('Invalid folder name', 400)
      }
      const subdir = parsed.data.subdir && isSafeRelativePath(parsed.data.subdir) ? parsed.data.subdir : ''
      const target = path.join(uploadsRoot, subdir, name)
      const rel = path.relative(uploadsRoot, target)
      if (rel.startsWith('..') || path.isAbsolute(rel)) return apiError('Path traversal', 400)
      await fs.mkdir(target, { recursive: true })
      return apiSuccess({ ok: true, dir: name })
    }
    if (parsed.data.action === 'rename') {
      // rename a file by id (rename originalName + disk file)
      const fileId = (json.fileId as string) ?? null
      if (!fileId) return apiError('fileId is required', 400)
      const file = await db.projectFile.findUnique({ where: { id: fileId } })
      if (!file || file.projectId !== project.id) return apiError('File not found', 404)
      const newName = parsed.data.newName!
      const oldPath = path.join(uploadsRoot, file.relPath)
      const dir = path.dirname(oldPath)
      const ext = path.extname(file.filename)
      const newDisk = randomFilename(newName)
      const newPath = path.join(dir, newDisk)
      await fs.rename(oldPath, newPath).catch(() => {})
      const newRel = path.posix.join(path.dirname(file.relPath), newDisk)
      await db.projectFile.update({
        where: { id: file.id },
        data: { filename: newDisk, originalName: newName, relPath: newRel },
      })
      return apiSuccess({ ok: true, originalName: newName })
    }
    return apiError('Unknown action', 400)
  } catch (e) {
    return handleApiError(e)
  }
}
