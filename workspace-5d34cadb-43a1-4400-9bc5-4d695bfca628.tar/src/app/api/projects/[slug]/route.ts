import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSession, requireCsrf, getClientIp } from '@/lib/auth'
import { apiSuccess, handleApiError, apiError } from '@/lib/api-utils'
import { dirSizeBytes, formatBytes, projectStorageRoot, projectUploadsDir, countFiles } from '@/lib/storage'
import { publicApiUrl } from '@/lib/backup'
import { logActivity, logSystem } from '@/lib/logger'
import { z } from 'zod'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(_req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const { slug } = await ctx.params
    const project = await db.project.findUnique({ where: { slug } })
    if (!project) return apiError('Project not found', 404)
    const [storageBytes, uploadsBytes, fileCount, resourceCount, apiRequestCount, lastLogs, settings] =
      await Promise.all([
        dirSizeBytes(projectStorageRoot(slug)),
        dirSizeBytes(projectUploadsDir(slug)),
        countFiles(projectUploadsDir(slug)),
        db.projectResource.count({ where: { projectId: project.id } }),
        db.apiLog.count({ where: { projectId: project.id } }),
        db.apiLog.findMany({
          where: { projectId: project.id },
          orderBy: { createdAt: 'desc' },
          take: 5,
        }),
        db.projectSetting.findMany({ where: { projectId: project.id } }),
      ])
    return apiSuccess({
      project: {
        id: project.id,
        name: project.name,
        slug: project.slug,
        description: project.description,
        status: project.status,
        version: project.version,
        apiEnabled: project.apiEnabled,
        rateLimit: project.rateLimit,
        hasApiKey: !!project.apiKeyHash,
        apiKeyHint: project.apiKeyHint,
        apiUrl: publicApiUrl(slug),
        storageBytes,
        storage: formatBytes(storageBytes),
        uploadsBytes,
        uploads: formatBytes(uploadsBytes),
        fileCount,
        resourceCount,
        apiRequestCount,
        createdAt: project.createdAt,
        updatedAt: project.updatedAt,
        lastActivity: project.lastActivity,
        settings: settings.reduce<Record<string, string>>((acc, s) => {
          acc[s.key] = s.value
          return acc
        }, {}),
        recentLogs: lastLogs,
      },
    })
  } catch (e) {
    return handleApiError(e)
  }
}

const patchBody = z.object({
  name: z.string().min(2).max(80).optional(),
  description: z.string().min(0).max(2000).optional(),
  version: z.string().min(1).max(20).optional(),
  rateLimit: z.number().int().min(1).max(10000).optional(),
})

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const csrf = req.headers.get('x-pbm-csrf') ?? undefined
    requireCsrf(sess.csrf, csrf)
    const { slug } = await ctx.params
    const project = await db.project.findUnique({ where: { slug } })
    if (!project) return apiError('Project not found', 404)
    const json = await req.json().catch(() => null)
    const parsed = patchBody.safeParse(json)
    if (!parsed.success) return apiError('Invalid input', 400)
    const updated = await db.project.update({
      where: { id: project.id },
      data: parsed.data,
    })
    await logActivity({
      action: 'project.update',
      projectId: project.id,
      message: `Project "${updated.name}" updated`,
      ip: getClientIp(req),
    })
    return apiSuccess({ project: { id: updated.id, name: updated.name, slug: updated.slug, description: updated.description, version: updated.version, rateLimit: updated.rateLimit, updatedAt: updated.updatedAt } })
  } catch (e) {
    return handleApiError(e)
  }
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const csrf = req.headers.get('x-pbm-csrf') ?? undefined
    requireCsrf(sess.csrf, csrf)
    const body = await req.json().catch(() => ({}))
    const confirmName = (body as { confirm?: string })?.confirm ?? ''
    const { slug } = await ctx.params
    const project = await db.project.findUnique({ where: { slug } })
    if (!project) return apiError('Project not found', 404)
    if (confirmName !== project.name) {
      return apiError('Project name does not match. Deletion cancelled.', 400)
    }
    await db.project.delete({ where: { id: project.id } })
    const { removeProjectStorage } = await import('@/lib/storage')
    await removeProjectStorage(project.slug).catch(() => {})
    await logActivity({
      action: 'project.delete',
      message: `Project "${project.name}" (${project.slug}) deleted`,
      ip: getClientIp(req),
    })
    await logSystem({ category: 'system', level: 'warn', message: `Project deleted: ${project.slug}` })
    return apiSuccess({ deleted: true })
  } catch (e) {
    return handleApiError(e)
  }
}
