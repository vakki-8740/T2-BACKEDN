"use client";

import * as React from "react";
import {
  LayoutDashboard,
  FolderKanban,
  ShieldCheck,
  ScrollText,
  Settings as SettingsIcon,
  Boxes,
  LogOut,
  LifeBuoy,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAppStore, type ViewKey } from "@/stores/app-store";
import { apiFetch } from "@/lib/api-client";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const NAV: {
  key: ViewKey;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}[] = [
  { key: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { key: "projects", label: "Projects", icon: FolderKanban },
  { key: "security", label: "Security", icon: ShieldCheck },
  { key: "logs", label: "Logs", icon: ScrollText },
  { key: "settings", label: "Settings", icon: SettingsIcon },
];

export function SidebarNav({ onNavigate }: { onNavigate?: () => void }) {
  const view = useAppStore((s) => s.view);
  const setView = useAppStore((s) => s.setView);
  const setSelectedProjectSlug = useAppStore((s) => s.setSelectedProjectSlug);

  function selectView(v: ViewKey) {
    if (v !== "project") setSelectedProjectSlug(null);
    setView(v);
    onNavigate?.();
  }

  return (
    <nav className="flex-1 space-y-0.5">
      {NAV.map(({ key, label, icon: Icon }) => {
        const active = view === key || (key === "projects" && view === "project");
        return (
          <button
            key={key}
            onClick={() => selectView(key)}
            className={cn(
              "flex w-full items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium transition-colors",
              active
                ? "bg-secondary text-secondary-foreground"
                : "text-muted-foreground hover:bg-accent hover:text-foreground",
            )}
          >
            <Icon className="size-4" />
            <span>{label}</span>
          </button>
        );
      })}
    </nav>
  );
}

export function SidebarBranding({ systemName }: { systemName?: string }) {
  return (
    <div className="flex items-center gap-2 px-1 py-1">
      <div className="flex size-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
        <Boxes className="size-4" />
      </div>
      <div className="flex flex-col leading-tight">
        <span className="text-sm font-semibold truncate max-w-[160px]">
          {systemName || "Project Backend Manager"}
        </span>
        <span className="text-[11px] text-muted-foreground">v1.0</span>
      </div>
    </div>
  );
}

export function SidebarFooter() {
  async function logout() {
    try {
      await apiFetch("/api/auth/logout", { method: "POST" });
      toast.success("Signed out");
    } catch {
      toast.error("Could not sign out");
    } finally {
      // hard refresh to drop client state cleanly
      if (typeof window !== "undefined") window.location.reload();
    }
  }

  return (
    <div className="space-y-1">
      <Button
        variant="ghost"
        size="sm"
        className="w-full justify-start text-muted-foreground hover:text-foreground"
        onClick={logout}
      >
        <LogOut className="size-4" />
        <span>Sign out</span>
      </Button>
      <div className="flex items-center gap-1 px-3 py-1 text-[11px] text-muted-foreground">
        <LifeBuoy className="size-3" />
        <span>Secure multi-project backend</span>
      </div>
    </div>
  );
}

/** Desktop sidebar (240px fixed) */
export function DesktopSidebar({ systemName }: { systemName?: string }) {
  return (
    <aside className="hidden md:flex md:flex-col w-60 shrink-0 border-r bg-sidebar text-sidebar-foreground">
      <div className="p-4 border-b">
        <SidebarBranding systemName={systemName} />
      </div>
      <div className="flex flex-1 flex-col gap-1 p-3">
        <SidebarNav />
      </div>
      <div className="border-t p-3">
        <SidebarFooter />
      </div>
    </aside>
  );
}
