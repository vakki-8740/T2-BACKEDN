import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSession, requireCsrf, getClientIp } from '@/lib/auth'
import { apiSuccess, handleApiError, apiError } from '@/lib/api-utils'
import { logActivity } from '@/lib/logger'
import { z } from 'zod'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

// GET /api/projects/[slug]/resources?collection=users
export async function GET(req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const { slug } = await ctx.params
    const project = await db.project.findUnique({ where: { slug } })
    if (!project) return apiError('Project not found', 404)
    const collection = req.nextUrl.searchParams.get('collection') ?? 'default'
    const resources = await db.projectResource.findMany({
      where: { projectId: project.id, collection },
      orderBy: { createdAt: 'asc' },
    })
    return apiSuccess({
      collection,
      resources: resources.map((r) => ({
        id: r.id,
        key: r.key,
        value: r.value,
        createdAt: r.createdAt,
        updatedAt: r.updatedAt,
      })),
    })
  } catch (e) {
    return handleApiError(e)
  }
}

const createBody = z.object({
  collection: z.string().min(1).max(64).default('default'),
  key: z.string().min(1).max(128),
  value: z.string().max(1_000_000),
})

export async function POST(req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const csrf = req.headers.get('x-pbm-csrf') ?? undefined
    requireCsrf(sess.csrf, csrf)
    const { slug } = await ctx.params
    const project = await db.project.findUnique({ where: { slug } })
    if (!project) return apiError('Project not found', 404)
    const json = await req.json().catch(() => null)
    const parsed = createBody.safeParse(json)
    if (!parsed.success) return apiError('Invalid input', 400, { issues: parsed.error.issues })
    const existing = await db.projectResource.findUnique({
      where: { projectId_collection_key: { projectId: project.id, collection: parsed.data.collection, key: parsed.data.key } },
    })
    if (existing) return apiError('A resource with this key already exists in this collection', 409)
    const r = await db.projectResource.create({
      data: { projectId: project.id, collection: parsed.data.collection, key: parsed.data.key, value: parsed.data.value },
    })
    await logActivity({
      action: 'resource.create',
      projectId: project.id,
      message: `Resource created in ${parsed.data.collection}/${parsed.data.key}`,
      ip: getClientIp(req),
    })
    return apiSuccess({ id: r.id, key: r.key, value: r.value, collection: r.collection }, 201)
  } catch (e) {
    return handleApiError(e)
  }
}

const updateBody = z.object({
  value: z.string().max(1_000_000),
})

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const csrf = req.headers.get('x-pbm-csrf') ?? undefined
    requireCsrf(sess.csrf, csrf)
    const { slug } = await ctx.params
    const project = await db.project.findUnique({ where: { slug } })
    if (!project) return apiError('Project not found', 404)
    const id = req.nextUrl.searchParams.get('id')
    if (!id) return apiError('id is required', 400)
    const json = await req.json().catch(() => null)
    const parsed = updateBody.safeParse(json)
    if (!parsed.success) return apiError('Invalid input', 400)
    const r = await db.projectResource.update({
      where: { id },
      data: { value: parsed.data.value },
    })
    await logActivity({
      action: 'resource.update',
      projectId: project.id,
      message: `Resource updated: ${r.collection}/${r.key}`,
      ip: getClientIp(req),
    })
    return apiSuccess({ id: r.id, value: r.value })
  } catch (e) {
    return handleApiError(e)
  }
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const csrf = req.headers.get('x-pbm-csrf') ?? undefined
    requireCsrf(sess.csrf, csrf)
    const { slug } = await ctx.params
    const project = await db.project.findUnique({ where: { slug } })
    if (!project) return apiError('Project not found', 404)
    const id = req.nextUrl.searchParams.get('id')
    if (!id) return apiError('id is required', 400)
    const r = await db.projectResource.delete({ where: { id } })
    await logActivity({
      action: 'resource.delete',
      projectId: project.id,
      message: `Resource deleted: ${r.collection}/${r.key}`,
      ip: getClientIp(req),
    })
    return apiSuccess({ deleted: true })
  } catch (e) {
    return handleApiError(e)
  }
}
