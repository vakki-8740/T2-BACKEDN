import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSession } from '@/lib/auth'
import { apiSuccess, handleApiError, apiError } from '@/lib/api-utils'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const type = req.nextUrl.searchParams.get('type') ?? 'activity'
    const limit = Math.min(Number(req.nextUrl.searchParams.get('limit') ?? '100'), 500)
    if (type === 'system') {
      const [sys, api] = await Promise.all([
        db.systemLog.findMany({ orderBy: { createdAt: 'desc' }, take: limit }),
        db.apiLog.findMany({ orderBy: { createdAt: 'desc' }, take: limit, include: { project: { select: { slug: true, name: true } } } }),
      ])
      return apiSuccess({
        type: 'system',
        systemLogs: sys,
        apiLogs: api,
      })
    }
    if (type === 'api') {
      const logs = await db.apiLog.findMany({
        orderBy: { createdAt: 'desc' },
        take: limit,
        include: { project: { select: { slug: true, name: true } } },
      })
      return apiSuccess({ type: 'api', logs })
    }
    const activity = await db.activityLog.findMany({ orderBy: { createdAt: 'desc' }, take: limit })
    return apiSuccess({ type: 'activity', logs: activity })
  } catch (e) {
    return handleApiError(e)
  }
}
