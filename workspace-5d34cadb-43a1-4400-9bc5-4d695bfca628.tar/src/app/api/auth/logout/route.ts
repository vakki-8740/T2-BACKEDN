import { NextRequest } from 'next/server'
import { destroySession, getSession, clearSessionCookie, getClientIp } from '@/lib/auth'
import { apiSuccess, handleApiError } from '@/lib/api-utils'
import { logActivity } from '@/lib/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function POST(req: NextRequest) {
  try {
    const sess = await getSession()
    if (sess) {
      const tokenCookie = (await import('next/headers')).cookies
      const token = (await tokenCookie).get('pbm_session')?.value
      if (token) destroySession(token)
      await logActivity({
        action: 'admin.logout',
        message: `Admin signed out: ${sess.email}`,
        ip: getClientIp(req),
      })
    }
    await clearSessionCookie()
    return apiSuccess({ ok: true })
  } catch (e) {
    return handleApiError(e)
  }
}
