"use client";

import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import { Loader2, Save } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { apiFetch, ApiError } from "@/lib/api-client";
import { toast } from "sonner";

export function SettingsView() {
  const { data, isLoading } = useQuery<{ settings: Record<string, string> }>({
    queryKey: ["settings"],
    queryFn: () => apiFetch<{ settings: Record<string, string> }>("/api/settings"),
  });

  const [form, setForm] = React.useState({
    systemName: "",
    baseUrl: "",
    maxUploadMb: "10",
    defaultRateLimit: "100",
    sessionTimeoutMinutes: "720",
  });
  const [saving, setSaving] = React.useState(false);

  React.useEffect(() => {
    if (data?.settings) {
      setForm({
        systemName: data.settings.systemName ?? "",
        baseUrl: data.settings.baseUrl ?? "",
        maxUploadMb: data.settings.maxUploadMb ?? "10",
        defaultRateLimit: data.settings.defaultRateLimit ?? "100",
        sessionTimeoutMinutes: data.settings.sessionTimeoutMinutes ?? "720",
      });
    }
  }, [data]);

  function update<K extends keyof typeof form>(k: K, v: string) {
    setForm((f) => ({ ...f, [k]: v }));
  }

  async function onSave() {
    setSaving(true);
    try {
      await apiFetch("/api/settings", {
        method: "PATCH",
        body: JSON.stringify(form),
      });
      toast.success("Settings saved");
    } catch (err) {
      toast.error(err instanceof ApiError ? err.message : "Could not save settings");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h2 className="text-xl font-semibold tracking-tight">Settings</h2>
        <p className="text-sm text-muted-foreground">
          Global system settings applied to all projects and admin sessions.
        </p>
      </div>

      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle className="text-sm">General</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {isLoading ? (
            <div className="space-y-3">
              <Skeleton className="h-9 w-full" />
              <Skeleton className="h-9 w-full" />
              <Skeleton className="h-9 w-full" />
            </div>
          ) : (
            <>
              <div className="space-y-1.5">
                <Label htmlFor="system-name">System name</Label>
                <Input
                  id="system-name"
                  value={form.systemName}
                  onChange={(e) => update("systemName", e.target.value)}
                  placeholder="Project Backend Manager"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="base-url">Base URL</Label>
                <Input
                  id="base-url"
                  value={form.baseUrl}
                  onChange={(e) => update("baseUrl", e.target.value)}
                  placeholder="https://example.com"
                />
                <p className="text-[11px] text-muted-foreground">
                  Used when generating project API URLs. Leave empty to use the current host.
                </p>
              </div>
              <div className="grid gap-3 md:grid-cols-3">
                <div className="space-y-1.5">
                  <Label htmlFor="max-up">Max upload size (MB)</Label>
                  <Input
                    id="max-up"
                    type="number"
                    min={1}
                    max={1024}
                    value={form.maxUploadMb}
                    onChange={(e) => update("maxUploadMb", String(e.target.value || 1))}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="def-rl">Default rate limit</Label>
                  <Input
                    id="def-rl"
                    type="number"
                    min={1}
                    max={10000}
                    value={form.defaultRateLimit}
                    onChange={(e) => update("defaultRateLimit", String(e.target.value || 1))}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="session-timeout">Session timeout (min)</Label>
                  <Input
                    id="session-timeout"
                    type="number"
                    min={5}
                    max={10080}
                    value={form.sessionTimeoutMinutes}
                    onChange={(e) =>
                      update("sessionTimeoutMinutes", String(e.target.value || 5))
                    }
                  />
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      <div className="flex items-center justify-end">
        <Button onClick={onSave} disabled={saving || isLoading}>
          {saving ? (
            <Loader2 className="size-4 animate-spin" />
          ) : (
            <Save className="size-4" />
          )}
          Save settings
        </Button>
      </div>
    </div>
  );
}
