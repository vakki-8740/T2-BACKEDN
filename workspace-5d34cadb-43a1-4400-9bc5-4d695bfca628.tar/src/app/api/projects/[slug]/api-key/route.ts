import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSession, requireCsrf, getClientIp } from '@/lib/auth'
import { apiSuccess, handleApiError, apiError } from '@/lib/api-utils'
import { randomToken } from '@/lib/security'
import { logActivity } from '@/lib/logger'
import bcrypt from 'bcryptjs'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function POST(req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const csrf = req.headers.get('x-pbm-csrf') ?? undefined
    requireCsrf(sess.csrf, csrf)
    const { slug } = await ctx.params
    const project = await db.project.findUnique({ where: { slug } })
    if (!project) return apiError('Project not found', 404)
    const action = req.nextUrl.searchParams.get('action') ?? 'regenerate'
    if (action === 'revoke') {
      await db.project.update({
        where: { id: project.id },
        data: { apiKeyHash: null, apiKeyHint: null, apiEnabled: false },
      })
      await logActivity({
        action: 'apikey.revoke',
        projectId: project.id,
        message: `API key revoked for "${project.name}"`,
        ip: getClientIp(req),
      })
      return apiSuccess({ revoked: true })
    }
    // regenerate
    const apiKey = `pb_${project.slug}_${randomToken(20)}`
    const apiKeyHash = await bcrypt.hash(apiKey, 10)
    await db.project.update({
      where: { id: project.id },
      data: { apiKeyHash, apiKeyHint: apiKey.slice(-4), apiEnabled: true },
    })
    await logActivity({
      action: 'apikey.regenerate',
      projectId: project.id,
      message: `API key regenerated for "${project.name}"`,
      ip: getClientIp(req),
    })
    return apiSuccess({ apiKey, apiKeyHint: apiKey.slice(-4) }) // returned once
  } catch (e) {
    return handleApiError(e)
  }
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const csrf = req.headers.get('x-pbm-csrf') ?? undefined
    requireCsrf(sess.csrf, csrf)
    const { slug } = await ctx.params
    const project = await db.project.findUnique({ where: { slug } })
    if (!project) return apiError('Project not found', 404)
    const json = (await req.json().catch(() => ({}))) as { apiEnabled?: boolean }
    const updated = await db.project.update({
      where: { id: project.id },
      data: { apiEnabled: json.apiEnabled ?? !project.apiEnabled },
    })
    await logActivity({
      action: 'apikey.toggle',
      projectId: project.id,
      message: `API authentication ${updated.apiEnabled ? 'enabled' : 'disabled'} for "${updated.name}"`,
      ip: getClientIp(req),
    })
    return apiSuccess({ apiEnabled: updated.apiEnabled })
  } catch (e) {
    return handleApiError(e)
  }
}
