"use client";

import * as React from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { AlertTriangle, KeyRound } from "lucide-react";
import { CopyButton } from "@/components/ui-primitives/copy-button";

/**
 * Reveal-once dialog showing an API key. The caller controls when this opens
 * and what `value` to show. After closing, the value should be cleared.
 */
export function ApiKeyRevealDialog({
  open,
  onOpenChange,
  value,
  title = "Your API key",
  description = "Copy this key now. For security, it will not be shown again.",
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  value: string | null;
  title?: string;
  description?: string;
}) {
  const [saved, setSaved] = React.useState(false);
  React.useEffect(() => {
    if (!open) setSaved(false);
  }, [open]);

  return (
    <Dialog
      open={open && !!value}
      onOpenChange={(v) => {
        if (!saved && v === false) {
          // do not allow closing until user confirms they saved it
          return;
        }
        onOpenChange(v);
      }}
    >
      <DialogContent className="sm:max-w-lg" showCloseButton={false}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <KeyRound className="size-5" />
            {title}
          </DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="flex items-center gap-2 rounded-md border bg-muted p-3">
            <code className="flex-1 font-mono text-sm break-all select-all">
              {value}
            </code>
            <CopyButton value={value ?? ""} />
          </div>
          <div className="flex items-start gap-2 rounded-md bg-amber-50 border border-amber-200 p-3 text-amber-800 text-xs dark:bg-amber-950/40 dark:border-amber-900 dark:text-amber-200">
            <AlertTriangle className="size-3.5 mt-0.5 shrink-0" />
            <span>
              Treat this key like a password. Anyone with this key can read and write data
              in this project, subject to the project rate limits.
            </span>
          </div>
          <label className="flex items-start gap-2 cursor-pointer pt-1">
            <Checkbox
              id="saved-key"
              checked={saved}
              onCheckedChange={(v) => setSaved(Boolean(v))}
            />
            <Label htmlFor="saved-key" className="cursor-pointer text-sm">
              I&apos;ve saved the key securely
            </Label>
          </label>
        </div>
        <DialogFooter>
          <Button
            type="button"
            disabled={!saved}
            onClick={() => onOpenChange(false)}
          >
            Done
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
