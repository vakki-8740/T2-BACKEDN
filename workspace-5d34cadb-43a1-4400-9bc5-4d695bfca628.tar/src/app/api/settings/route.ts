import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSession, requireCsrf, getClientIp } from '@/lib/auth'
import { apiSuccess, handleApiError, apiError } from '@/lib/api-utils'
import { logActivity } from '@/lib/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const rows = await db.setting.findMany()
    const map: Record<string, string> = {}
    for (const r of rows) map[r.key] = r.value
    return apiSuccess({ settings: map })
  } catch (e) {
    return handleApiError(e)
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const csrf = req.headers.get('x-pbm-csrf') ?? undefined
    requireCsrf(sess.csrf, csrf)
    const json = (await req.json().catch(() => ({}))) as Record<string, string>
    const allowed = new Set(['systemName', 'maxUploadMb', 'defaultRateLimit', 'sessionTimeoutMinutes', 'baseUrl'])
    for (const [k, v] of Object.entries(json)) {
      if (!allowed.has(k)) continue
      await db.setting.upsert({
        where: { key: k },
        update: { value: String(v) },
        create: { key: k, value: String(v) },
      })
    }
    await logActivity({
      action: 'settings.update',
      message: `Global settings updated`,
      ip: getClientIp(req),
    })
    const rows = await db.setting.findMany()
    const map: Record<string, string> = {}
    for (const r of rows) map[r.key] = r.value
    return apiSuccess({ settings: map })
  } catch (e) {
    return handleApiError(e)
  }
}
