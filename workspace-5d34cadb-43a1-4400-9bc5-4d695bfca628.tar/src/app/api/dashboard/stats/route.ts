import { db } from '@/lib/db'
import { getSession } from '@/lib/auth'
import { apiSuccess, handleApiError, apiError } from '@/lib/api-utils'
import { dirSizeBytes, formatBytes, projectStorageRoot } from '@/lib/storage'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const [total, active, disabled, maintenance, files, apiLogs, recentProjects, recentActivity, recentApiLogs] =
      await Promise.all([
        db.project.count(),
        db.project.count({ where: { status: 'ACTIVE' } }),
        db.project.count({ where: { status: 'DISABLED' } }),
        db.project.count({ where: { status: 'MAINTENANCE' } }),
        db.projectFile.count(),
        db.apiLog.count(),
        db.project.findMany({
          orderBy: { createdAt: 'desc' },
          take: 5,
        }),
        db.activityLog.findMany({
          orderBy: { createdAt: 'desc' },
          take: 8,
        }),
        db.apiLog.findMany({
          orderBy: { createdAt: 'desc' },
          take: 8,
          include: { project: { select: { slug: true, name: true } } },
        }),
      ])

    // storage size on disk
    let storageBytes = 0
    for (const p of await db.project.findMany({ select: { slug: true } })) {
      storageBytes += await dirSizeBytes(projectStorageRoot(p.slug))
    }

    return apiSuccess({
      stats: {
        totalProjects: total,
        activeProjects: active,
        disabledProjects: disabled,
        maintenanceProjects: maintenance,
        totalFiles: files,
        totalApiRequests: apiLogs,
        totalStorageBytes: storageBytes,
        totalStorage: formatBytes(storageBytes),
        databases: total,
      },
      recentProjects: recentProjects.map((p) => ({
        id: p.id,
        name: p.name,
        slug: p.slug,
        status: p.status,
        createdAt: p.createdAt,
        lastActivity: p.lastActivity,
      })),
      recentActivity: recentActivity.map((a) => ({
        id: a.id,
        action: a.action,
        message: a.message,
        createdAt: a.createdAt,
        projectId: a.projectId,
      })),
      recentApiLogs: recentApiLogs.map((l) => ({
        id: l.id,
        method: l.method,
        endpoint: l.endpoint,
        status: l.status,
        createdAt: l.createdAt,
        project: l.project,
      })),
    })
  } catch (e) {
    return handleApiError(e)
  }
}
