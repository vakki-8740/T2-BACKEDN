import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import {
  createSession,
  setSessionCookie,
  hasAdmin,
  checkLoginRate,
  recordFailedLogin,
  resetLoginRate,
  getClientIp,
} from '@/lib/auth'
import { apiError, apiSuccess, handleApiError } from '@/lib/api-utils'
import { logActivity, logSystem } from '@/lib/logger'
import bcrypt from 'bcryptjs'
import { z } from 'zod'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const body = z.object({
  email: z.string().email(),
  password: z.string().min(1).max(128),
})

export async function POST(req: NextRequest) {
  try {
    if (!(await hasAdmin())) {
      return apiError('Setup required. Please create the admin account first.', 412, { setupRequired: true })
    }
    const ip = getClientIp(req)
    const rl = checkLoginRate(ip)
    if (!rl.ok) {
      return apiError(`Too many failed login attempts. Try again in ${Math.ceil(rl.retryAfterMs / 1000)}s.`, 429)
    }
    const json = await req.json().catch(() => null)
    const parsed = body.safeParse(json)
    if (!parsed.success) {
      return apiError('Email and password are required.', 400)
    }
    const { email, password } = parsed.data
    const admin = await db.admin.findUnique({ where: { email: email.toLowerCase() } })
    if (!admin) {
      recordFailedLogin(ip)
      await logSystem({
        level: 'security',
        category: 'security',
        message: `Failed login for unknown email ${email} from ${ip}`,
      })
      return apiError('Invalid email or password.', 401)
    }
    const ok = await bcrypt.compare(password, admin.passwordHash)
    if (!ok) {
      recordFailedLogin(ip)
      await db.admin.update({
        where: { id: admin.id },
        data: { failedLogins: { increment: 1 } },
      })
      await logSystem({
        level: 'security',
        category: 'security',
        message: `Failed login for ${email} from ${ip}`,
      })
      return apiError('Invalid email or password.', 401)
    }
    resetLoginRate(ip)
    await db.admin.update({
      where: { id: admin.id },
      data: { failedLogins: 0, lastLoginAt: new Date() },
    })
    const { token, expiresAt, csrf } = createSession({ id: admin.id, email: admin.email, name: admin.name })
    await setSessionCookie(token, expiresAt)
    await logActivity({
      action: 'admin.login',
      message: `Admin signed in: ${admin.email}`,
      ip,
      userAgent: req.headers.get('user-agent') ?? undefined,
    })
    return apiSuccess({ email: admin.email, name: admin.name, csrf, expiresAt })
  } catch (e) {
    return handleApiError(e)
  }
}
