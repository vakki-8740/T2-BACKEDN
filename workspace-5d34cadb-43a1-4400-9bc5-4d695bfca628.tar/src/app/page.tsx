"use client";

import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth, apiFetch } from "@/lib/api-client";
import { useAppStore } from "@/stores/app-store";
import { FullScreenLoader } from "@/components/auth/full-screen-loader";
import { LoginScreen, SetupScreen } from "@/components/auth/auth-screens";
import { AppShell } from "@/components/layout/app-shell";
import { DashboardView } from "@/components/views/dashboard-view";
import { ProjectsView } from "@/components/views/projects-view";
import { ProjectDetailView } from "@/components/views/project-detail-view";
import { SecurityView } from "@/components/views/security-view";
import { LogsView } from "@/components/views/logs-view";
import { SettingsView } from "@/components/views/settings-view";

export default function Page() {
  const { status, me, refresh } = useAuth();
  const view = useAppStore((s) => s.view);
  const selectedProjectSlug = useAppStore((s) => s.selectedProjectSlug);

  // Load global settings (systemName) once authenticated
  const settingsQ = useQuery<{ settings: Record<string, string> }>({
    queryKey: ["settings"],
    queryFn: () => apiFetch<{ settings: Record<string, string> }>("/api/settings"),
    enabled: status === "authed",
  });
  const systemName = settingsQ.data?.settings?.systemName;

  if (status === "loading") {
    return <FullScreenLoader label="Loading your session…" />;
  }
  if (status === "setup") {
    return <SetupScreen onDone={async () => refresh()} />;
  }
  if (status === "login") {
    return <LoginScreen onDone={async () => refresh()} />;
  }

  return (
    <AppShell systemName={systemName} adminEmail={me?.admin?.email ?? null}>
      {view === "dashboard" && <DashboardView />}
      {view === "projects" && <ProjectsView />}
      {view === "project" &&
        (selectedProjectSlug ? (
          <ProjectDetailView slug={selectedProjectSlug} />
        ) : (
          <ProjectsView />
        ))}
      {view === "security" && <SecurityView />}
      {view === "logs" && <LogsView />}
      {view === "settings" && <SettingsView />}
    </AppShell>
  );
}
