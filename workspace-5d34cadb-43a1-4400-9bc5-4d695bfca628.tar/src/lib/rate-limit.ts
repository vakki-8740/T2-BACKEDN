import { db } from '@/lib/db'

// Per-project rate limiting using a minute-window SQLite counter.
// (Simple, documented limitation: in production at scale a Redis-style store is better.)

export type RateLimitResult = { allowed: boolean; remaining: number; resetInMs: number; limit: number }

function windowKeyFor(date = new Date()): string {
  // e.g. "2026-09-21T10:37" (UTC minute)
  const iso = date.toISOString()
  return iso.slice(0, 16) // YYYY-MM-DDTHH:MM
}

export async function checkProjectRateLimit(projectId: string, limitPerMin: number): Promise<RateLimitResult> {
  const wk = windowKeyFor()
  const existing = await db.rateLimitBucket.findUnique({
    where: { projectId_windowKey: { projectId, windowKey: wk } },
  })
  const current = existing?.count ?? 0
  const allowed = current < limitPerMin
  const remaining = Math.max(0, limitPerMin - current - (allowed ? 1 : 0))
  const now = Date.now()
  const nextMinute = Math.ceil(now / 60000) * 60000
  const resetInMs = Math.max(1000, nextMinute - now)
  if (allowed) {
    if (existing) {
      await db.rateLimitBucket.update({
        where: { projectId_windowKey: { projectId, windowKey: wk } },
        data: { count: { increment: 1 } },
      })
    } else {
      await db.rateLimitBucket.create({
        data: { projectId, windowKey: wk, count: 1 },
      })
    }
  }
  return { allowed, remaining, limit: limitPerMin, resetInMs }
}

// Garbage collect old buckets occasionally
export async function gcRateLimitBuckets() {
  const cutoff = new Date(Date.now() - 60 * 60 * 1000) // 1h ago
  try {
    await db.rateLimitBucket.deleteMany({ where: { createdAt: { lt: cutoff } } })
  } catch {
    // ignore
  }
}
