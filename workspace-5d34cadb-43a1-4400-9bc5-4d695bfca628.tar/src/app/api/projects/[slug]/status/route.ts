import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSession, requireCsrf, getClientIp } from '@/lib/auth'
import { apiSuccess, handleApiError, apiError } from '@/lib/api-utils'
import { logActivity } from '@/lib/logger'
import { z } from 'zod'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const body = z.object({
  status: z.enum(['ACTIVE', 'DISABLED', 'MAINTENANCE']),
})

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const csrf = req.headers.get('x-pbm-csrf') ?? undefined
    requireCsrf(sess.csrf, csrf)
    const { slug } = await ctx.params
    const project = await db.project.findUnique({ where: { slug } })
    if (!project) return apiError('Project not found', 404)
    const json = await req.json().catch(() => null)
    const parsed = body.safeParse(json)
    if (!parsed.success) return apiError('Invalid status', 400)
    const updated = await db.project.update({
      where: { id: project.id },
      data: { status: parsed.data.status },
    })
    await logActivity({
      action: 'project.status',
      projectId: project.id,
      message: `Project "${updated.name}" status set to ${updated.status}`,
      ip: getClientIp(req),
    })
    return apiSuccess({ status: updated.status })
  } catch (e) {
    return handleApiError(e)
  }
}
