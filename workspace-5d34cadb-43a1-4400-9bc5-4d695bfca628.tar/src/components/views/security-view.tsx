"use client";

import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Boxes,
  Database,
  FolderArchive,
  KeyRound,
  Lock,
  Server,
  ShieldCheck,
  Timer,
  Upload,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { apiFetch } from "@/lib/api-client";
import { relativeTime } from "@/lib/format";

type SecurityData = {
  adminAuth: {
    enabled: boolean;
    email: string | null;
    name: string | null;
    lastLoginAt: string | null;
    createdAt: string | null;
  };
  csrfProtection: { enabled: boolean; note: string };
  apiAuth: { enabledProjects: number; totalProjects: number; note: string };
  rateLimiting: { enabled: boolean; defaultPerMinute: number; note: string };
  uploadRestrictions: { maxUploadMb: number; allowedMimesDefault: string };
  environment: {
    runtime: string;
    framework: string;
    database: string;
    nodeEnv: string;
  };
  storage: { writable: boolean; path: string };
  backups: { count: number };
  recentSecurityEvents: {
    id: string;
    message: string;
    createdAt: string;
    level: string;
  }[];
};

export function SecurityView() {
  const { data, isLoading } = useQuery<SecurityData>({
    queryKey: ["security"],
    queryFn: () => apiFetch<SecurityData>("/api/security"),
  });

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold tracking-tight">Security</h2>
        <p className="text-sm text-muted-foreground">
          A snapshot of the security posture enforced by the backend.
        </p>
      </div>

      {isLoading || !data ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-40 rounded-xl" />
          ))}
        </div>
      ) : (
        <>
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            <SecurityCard
              icon={Lock}
              title="Admin authentication"
              enabled={data.adminAuth.enabled}
              rows={[
                ["Admin", data.adminAuth.email ?? "—"],
                ["Name", data.adminAuth.name ?? "—"],
                ["Last login", data.adminAuth.lastLoginAt ? relativeTime(data.adminAuth.lastLoginAt) : "Never"],
                ["Created", data.adminAuth.createdAt ? relativeTime(data.adminAuth.createdAt) : "—"],
              ]}
            />
            <SecurityCard
              icon={KeyRound}
              title="CSRF protection"
              enabled={data.csrfProtection.enabled}
              rows={[
                ["Mechanism", "Per-session token"],
                ["Header", "X-PBM-CSRF"],
                ["Scope", "All state-changing admin routes"],
              ]}
              note={data.csrfProtection.note}
            />
            <SecurityCard
              icon={ShieldCheck}
              title="API authentication"
              enabled={data.apiAuth.enabledProjects > 0}
              rows={[
                ["Projects w/ API", `${data.apiAuth.enabledProjects} / ${data.apiAuth.totalProjects}`],
                ["Scheme", "Bearer token"],
                ["Storage", "bcrypt-hashed"],
              ]}
              note={data.apiAuth.note}
            />
            <SecurityCard
              icon={Timer}
              title="Rate limiting"
              enabled={data.rateLimiting.enabled}
              rows={[
                ["Default", `${data.rateLimiting.defaultPerMinute} req/min`],
                ["Granularity", "Per-project, per-minute"],
                ["Storage", "SQLite counter"],
              ]}
              note={data.rateLimiting.note}
            />
            <SecurityCard
              icon={Upload}
              title="Upload restrictions"
              enabled={true}
              rows={[
                ["Max upload size", `${data.uploadRestrictions.maxUploadMb} MB`],
                ["Allowed types", "Project + global whitelist"],
              ]}
              note={`Default whitelist: ${data.uploadRestrictions.allowedMimesDefault}`}
            />
            <SecurityCard
              icon={FolderArchive}
              title="Backups"
              enabled={true}
              rows={[
                ["Total backups", String(data.backups.count)],
                ["Storage", "On-disk ZIP"],
                ["Scope", "Per-project"],
              ]}
            />
            <SecurityCard
              icon={Server}
              title="Runtime environment"
              enabled={true}
              rows={[
                ["Runtime", data.environment.runtime],
                ["Framework", data.environment.framework],
                ["Database", data.environment.database],
                ["Node env", data.environment.nodeEnv],
              ]}
            />
            <SecurityCard
              icon={Database}
              title="Storage"
              enabled={data.storage.writable}
              rows={[
                ["Writable", data.storage.writable ? "Yes" : "No"],
                ["Path", data.storage.path],
              ]}
            />
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm flex items-center gap-2">
                <ShieldCheck className="size-4" />
                Recent security events
              </CardTitle>
            </CardHeader>
            <CardContent className="px-6">
              {data.recentSecurityEvents.length === 0 ? (
                <div className="flex h-20 items-center justify-center text-xs text-muted-foreground">
                  <span className="flex items-center gap-2">
                    <Boxes className="size-4" /> No security events yet
                  </span>
                </div>
              ) : (
                <ul className="divide-y">
                  {data.recentSecurityEvents.map((e) => (
                    <li key={e.id} className="py-2 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2 min-w-0">
                        <span className={`size-1.5 rounded-full ${levelDot(e.level)}`} />
                        <span className="text-sm truncate">{e.message}</span>
                      </div>
                      <span className="text-[11px] text-muted-foreground whitespace-nowrap">
                        {relativeTime(e.createdAt)}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}

function levelDot(level: string) {
  switch ((level || "").toLowerCase()) {
    case "warn":
      return "bg-amber-500";
    case "error":
      return "bg-red-500";
    case "security":
      return "bg-emerald-500";
    default:
      return "bg-muted-foreground";
  }
}

function SecurityCard({
  icon: Icon,
  title,
  enabled,
  rows,
  note,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  enabled: boolean;
  rows: [string, string][];
  note?: string;
}) {
  return (
    <Card className="shadow-sm">
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            <span className="flex size-8 items-center justify-center rounded-md bg-muted text-muted-foreground">
              <Icon className="size-4" />
            </span>
            <CardTitle className="text-sm font-medium">{title}</CardTitle>
          </div>
          <span
            className={`rounded-full border px-2 py-0.5 text-[10px] font-medium uppercase ${
              enabled
                ? "bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-950 dark:text-emerald-300 dark:border-emerald-900"
                : "bg-muted text-muted-foreground"
            }`}
          >
            {enabled ? "Enabled" : "Off"}
          </span>
        </div>
      </CardHeader>
      <CardContent className="space-y-1 pt-0">
        <dl className="grid grid-cols-2 gap-x-3 gap-y-1 text-xs">
          {rows.map(([k, v]) => (
            <React.Fragment key={k}>
              <dt className="text-muted-foreground">{k}</dt>
              <dd className="font-medium text-right truncate" title={v}>
                {v}
              </dd>
            </React.Fragment>
          ))}
        </dl>
        {note ? (
          <p className="text-[11px] text-muted-foreground pt-2 border-t mt-2">{note}</p>
        ) : null}
      </CardContent>
    </Card>
  );
}
