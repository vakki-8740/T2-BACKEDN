"use client";

import * as React from "react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export type ProjectStatus = "ACTIVE" | "DISABLED" | "MAINTENANCE";

const statusClasses: Record<ProjectStatus, string> = {
  ACTIVE: "border-transparent bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300",
  DISABLED: "border-transparent bg-muted text-muted-foreground",
  MAINTENANCE: "border-transparent bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300",
};

export function StatusBadge({
  status,
  className,
}: {
  status: ProjectStatus | string;
  className?: string;
}) {
  const s = (status as ProjectStatus) in statusClasses ? (status as ProjectStatus) : "ACTIVE";
  return (
    <Badge variant="outline" className={cn("font-medium", statusClasses[s], className)}>
      <span className="size-1.5 rounded-full bg-current opacity-70" />
      {s}
    </Badge>
  );
}

export function HttpBadge({ status, className }: { status: number; className?: string }) {
  let cls =
    "border-transparent bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300";
  if (status >= 500)
    cls =
      "border-transparent bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300";
  else if (status >= 400)
    cls =
      "border-transparent bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300";
  else if (status >= 300)
    cls = "border-transparent bg-muted text-muted-foreground";
  return (
    <Badge variant="outline" className={cn("font-mono font-medium", cls, className)}>
      {status}
    </Badge>
  );
}

export function MethodBadge({ method, className }: { method: string; className?: string }) {
  let cls = "border-transparent bg-muted text-muted-foreground";
  if (method === "GET")
    cls =
      "border-transparent bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300";
  if (method === "POST")
    cls =
      "border-transparent bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300";
  if (method === "PATCH" || method === "PUT")
    cls =
      "border-transparent bg-amber-50 text-amber-800 dark:bg-amber-950 dark:text-amber-300";
  if (method === "DELETE")
    cls =
      "border-transparent bg-red-50 text-red-700 dark:bg-red-950 dark:text-red-300";
  return (
    <Badge variant="outline" className={cn("font-mono font-medium", cls, className)}>
      {method}
    </Badge>
  );
}

export function EnabledBadge({
  enabled,
  className,
  labelEnabled = "Enabled",
  labelDisabled = "Disabled",
}: {
  enabled: boolean;
  className?: string;
  labelEnabled?: string;
  labelDisabled?: string;
}) {
  return (
    <Badge
      variant="outline"
      className={cn(
        "font-medium border-transparent",
        enabled
          ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300"
          : "bg-muted text-muted-foreground",
        className,
      )}
    >
      <span className="size-1.5 rounded-full bg-current opacity-70" />
      {enabled ? labelEnabled : labelDisabled}
    </Badge>
  );
}
