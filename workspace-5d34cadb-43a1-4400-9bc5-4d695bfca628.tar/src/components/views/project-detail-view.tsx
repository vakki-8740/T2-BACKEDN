"use client";

import * as React from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ArrowLeft,
  Boxes,
  Copy,
  Download,
  ExternalLink,
  Loader2,
  MoreHorizontal,
  Pencil,
  RefreshCw,
  Save,
  Settings as SettingsIcon,
  Trash2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { StatCard } from "@/components/ui-primitives/stat-card";
import { StatusBadge, MethodBadge, HttpBadge } from "@/components/ui-primitives/status-badge";
import { CopyButton } from "@/components/ui-primitives/copy-button";
import { Skeleton } from "@/components/ui/skeleton";
import { apiFetch, ApiError } from "@/lib/api-client";
import { toast } from "sonner";
import { useAppStore } from "@/stores/app-store";
import { formatDate, relativeTime } from "@/lib/format";
import { FileManager } from "@/components/project/file-manager";
import { ResourceExplorer } from "@/components/project/resource-explorer";
import { ApiKeyRevealDialog } from "@/components/project/api-key-reveal-dialog";
import { DeleteProjectDialog } from "@/components/project/delete-project-dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

type ProjectDetail = {
  project: {
    id: string;
    name: string;
    slug: string;
    description?: string;
    status: "ACTIVE" | "DISABLED" | "MAINTENANCE";
    version: string;
    apiEnabled: boolean;
    rateLimit: number;
    hasApiKey: boolean;
    apiKeyHint?: string | null;
    apiUrl: string;
    storageBytes: number;
    storage: string;
    uploadsBytes: number;
    uploads: string;
    fileCount: number;
    resourceCount: number;
    apiRequestCount: number;
    createdAt: string;
    updatedAt: string;
    lastActivity: string | null;
    settings: Record<string, string>;
    recentLogs: ApiLogEntry[];
  };
};

type ApiLogEntry = {
  id: string;
  method: string;
  endpoint: string;
  status: number;
  ip?: string;
  responseMs?: number;
  createdAt: string;
};

export function ProjectDetailView({ slug }: { slug: string }) {
  const setView = useAppStore((s) => s.setView);
  const queryClient = useQueryClient();
  const { data, isLoading, refetch, isFetching } = useQuery<ProjectDetail>({
    queryKey: ["project", slug],
    queryFn: () => apiFetch<ProjectDetail>(`/api/projects/${slug}`),
  });

  const [tab, setTab] = React.useState("overview");
  const [revealedKey, setRevealedKey] = React.useState<string | null>(null);
  const [revokeOpen, setRevokeOpen] = React.useState(false);
  const [deleteOpen, setDeleteOpen] = React.useState(false);
  const [statusMenuOpen, setStatusMenuOpen] = React.useState(false);

  const p = data?.project;

  async function changeStatus(status: "ACTIVE" | "DISABLED" | "MAINTENANCE") {
    try {
      await apiFetch(`/api/projects/${slug}/status`, {
        method: "PATCH",
        body: JSON.stringify({ status }),
      });
      toast.success(`Status set to ${status}`);
      refetch();
    } catch (err) {
      toast.error(err instanceof ApiError ? err.message : "Could not update status");
    }
  }

  async function regenerateKey() {
    try {
      const r = await apiFetch<{ apiKey: string; apiKeyHint: string }>(
        `/api/projects/${slug}/api-key`,
        { method: "POST" },
      );
      toast.success("New API key generated");
      setRevealedKey(r.apiKey);
      refetch();
    } catch (err) {
      toast.error(err instanceof ApiError ? err.message : "Could not regenerate key");
    }
  }

  async function revokeKey() {
    try {
      await apiFetch(`/api/projects/${slug}/api-key?action=revoke`, {
        method: "POST",
      });
      toast.success("API key revoked");
      setRevokeOpen(false);
      refetch();
    } catch (err) {
      toast.error(err instanceof ApiError ? err.message : "Could not revoke key");
    }
  }

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!data || !p) {
    return (
      <div className="space-y-3">
        <Button variant="ghost" size="sm" onClick={() => setView("projects")}>
          <ArrowLeft className="size-4" /> Back to projects
        </Button>
        <Card>
          <CardContent className="p-8 text-center text-sm text-muted-foreground">
            Project not found.
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
        <div className="flex flex-col gap-3">
          <Button
            variant="ghost"
            size="sm"
            className="-ml-2 w-fit"
            onClick={() => setView("projects")}
          >
            <ArrowLeft className="size-4" /> Projects
          </Button>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl font-semibold tracking-tight">{p.name}</h2>
              <StatusBadge status={p.status} />
              <code className="text-[11px] font-mono text-muted-foreground px-1.5 py-0.5 rounded bg-muted">
                {p.id}
              </code>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {p.description || "No description provided."}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="outline" size="sm" asChild>
            <a href={`/api/public/${p.slug}/`} target="_blank" rel="noopener noreferrer">
              <ExternalLink className="size-4" />
              Open API
            </a>
          </Button>
          <Button variant="outline" size="sm" asChild>
            <a href={`/api/projects/${p.slug}/backup`}>
              <Download className="size-4" />
              Backup
            </a>
          </Button>
          <DropdownMenu open={statusMenuOpen} onOpenChange={setStatusMenuOpen}>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <MoreHorizontal className="size-4" />
                Status
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Set status</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => changeStatus("ACTIVE")}>
                <Boxes className="size-4" /> Active
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => changeStatus("MAINTENANCE")}>
                <Pencil className="size-4" /> Maintenance
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => changeStatus("DISABLED")}>
                <SettingsIcon className="size-4" /> Disable
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Button
            variant="outline"
            size="sm"
            className="text-destructive hover:text-destructive"
            onClick={() => setDeleteOpen(true)}
          >
            <Trash2 className="size-4" /> Delete
          </Button>
        </div>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="flex-wrap h-auto">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="api">API</TabsTrigger>
          <TabsTrigger value="database">Database</TabsTrigger>
          <TabsTrigger value="files">Files</TabsTrigger>
          <TabsTrigger value="uploads">Uploads</TabsTrigger>
          <TabsTrigger value="logs">Logs</TabsTrigger>
          <TabsTrigger value="backup">Backup</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="pt-4">
          <OverviewTab slug={slug} project={p} isFetching={isFetching} />
        </TabsContent>
        <TabsContent value="api" className="pt-4">
          <ApiTab
            project={p}
            onRegenerate={regenerateKey}
            onRevoke={() => setRevokeOpen(true)}
            onToggleApi={async (enabled) => {
              try {
                await apiFetch(`/api/projects/${slug}/api-key`, {
                  method: "PATCH",
                  body: JSON.stringify({ apiEnabled: enabled }),
                });
                toast.success(`Public API ${enabled ? "enabled" : "disabled"}`);
                refetch();
              } catch (err) {
                toast.error(err instanceof ApiError ? err.message : "Could not toggle API");
              }
            }}
          />
        </TabsContent>
        <TabsContent value="database" className="pt-4">
          <DatabaseTab slug={slug} project={p} />
        </TabsContent>
        <TabsContent value="files" className="pt-4">
          <FileManager slug={slug} />
        </TabsContent>
        <TabsContent value="uploads" className="pt-4">
          <UploadsTab slug={slug} />
        </TabsContent>
        <TabsContent value="logs" className="pt-4">
          <LogsTab slug={slug} />
        </TabsContent>
        <TabsContent value="backup" className="pt-4">
          <BackupTab slug={slug} projectName={p.name} />
        </TabsContent>
        <TabsContent value="settings" className="pt-4">
          <SettingsTab slug={slug} project={p} onDelete={() => setDeleteOpen(true)} />
        </TabsContent>
      </Tabs>

      <ApiKeyRevealDialog
        open={!!revealedKey}
        onOpenChange={(v) => !v && setRevealedKey(null)}
        value={revealedKey}
        title="Your new API key"
      />

      <AlertDialog open={revokeOpen} onOpenChange={setRevokeOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Revoke the API key?</AlertDialogTitle>
            <AlertDialogDescription>
              All clients using the current key will receive 401 responses
              immediately. The public API will also be disabled until you
              generate a new key.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={revokeKey}
            >
              Revoke
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <DeleteProjectDialog
        open={deleteOpen}
        onOpenChange={setDeleteOpen}
        project={{ name: p.name, slug: p.slug }}
        onDeleted={() => {
          queryClient.invalidateQueries({ queryKey: ["projects"] });
          setView("projects");
        }}
      />
    </div>
  );
}

function OverviewTab({
  slug,
  project,
  isFetching,
}: {
  slug: string;
  project: ProjectDetail["project"];
  isFetching?: boolean;
}) {
  return (
    <div className="space-y-5">
      <div className="grid gap-3 grid-cols-2 md:grid-cols-3 xl:grid-cols-5">
        <StatCard label="Storage" value={project.storage} icon={Boxes} />
        <StatCard label="Uploads" value={project.uploads} icon={Download} />
        <StatCard label="Files" value={project.fileCount} icon={Copy} />
        <StatCard label="Resources" value={project.resourceCount} icon={Boxes} />
        <StatCard label="API requests" value={project.apiRequestCount} icon={ExternalLink} />
      </div>
      <Card>
        <CardHeader>
          <CardTitle className="text-sm flex items-center justify-between">
            Project metadata
            {isFetching && (
              <Loader2 className="size-3.5 animate-spin text-muted-foreground" />
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="grid gap-x-6 gap-y-2 grid-cols-1 md:grid-cols-2 text-sm">
          <MetaRow label="Project ID" value={<code className="font-mono text-xs">{project.id}</code>} />
          <MetaRow label="Slug" value={<code className="font-mono text-xs">{project.slug}</code>} />
          <MetaRow label="Version" value={project.version} />
          <MetaRow label="Rate limit" value={`${project.rateLimit}/min`} />
          <MetaRow label="Created at" value={formatDate(project.createdAt)} />
          <MetaRow label="Updated at" value={formatDate(project.updatedAt)} />
          <MetaRow
            label="Last activity"
            value={project.lastActivity ? relativeTime(project.lastActivity) : "—"}
          />
          <MetaRow label="API enabled" value={project.apiEnabled ? "Yes" : "No"} />
        </CardContent>
      </Card>
    </div>
  );
}

function MetaRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-0.5">
      <span className="text-[11px] uppercase tracking-wide text-muted-foreground">
        {label}
      </span>
      <span className="text-sm">{value}</span>
    </div>
  );
}

function ApiTab({
  project,
  onRegenerate,
  onRevoke,
  onToggleApi,
}: {
  project: ProjectDetail["project"];
  onRegenerate: () => void;
  onRevoke: () => void;
  onToggleApi: (enabled: boolean) => void;
}) {
  const [rateLimit, setRateLimit] = React.useState(project.rateLimit);
  const [saving, setSaving] = React.useState(false);

  async function saveRateLimit() {
    setSaving(true);
    try {
      await apiFetch(`/api/projects/${project.slug}/settings`, {
        method: "PATCH",
        body: JSON.stringify({ rateLimit }),
      });
      toast.success("Rate limit updated");
    } catch (err) {
      toast.error(err instanceof ApiError ? err.message : "Could not update rate limit");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">API endpoint</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="space-y-1.5">
            <Label>Public URL</Label>
            <div className="flex items-center gap-2 rounded-md border bg-muted p-2">
              <code className="flex-1 font-mono text-xs truncate">{project.apiUrl}</code>
              <CopyButton value={project.apiUrl} />
            </div>
          </div>
          <div className="flex items-center justify-between rounded-md border p-3">
            <div>
              <p className="text-sm font-medium">Public API enabled</p>
              <p className="text-xs text-muted-foreground">
                When disabled, requests return 403 even with a valid key.
              </p>
            </div>
            <Switch
              checked={project.apiEnabled}
              onCheckedChange={(v) => onToggleApi(Boolean(v))}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="rl">Rate limit (requests per minute)</Label>
            <div className="flex items-center gap-2">
              <Input
                id="rl"
                type="number"
                min={1}
                max={10000}
                value={rateLimit}
                onChange={(e) => setRateLimit(Number(e.target.value) || 0)}
              />
              <Button size="sm" variant="outline" onClick={saveRateLimit} disabled={saving}>
                <Save className="size-4" /> Save
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm">API key</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="rounded-md border bg-muted p-3">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">Status</span>
                {project.hasApiKey ? (
                  <StatusBadge status="ACTIVE" />
                ) : (
                  <StatusBadge status="DISABLED" />
                )}
              </div>
              <code className="font-mono text-xs text-muted-foreground">
                {project.hasApiKey ? `****${project.apiKeyHint ?? "????"}` : "—"}
              </code>
            </div>
          </div>
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-xs text-muted-foreground max-w-md">
              The full key is only ever shown once, when it is generated or regenerated.
              Store it securely.
            </p>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={onRegenerate}>
                <RefreshCw className="size-4" /> Regenerate
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="text-destructive hover:text-destructive"
                onClick={onRevoke}
                disabled={!project.hasApiKey}
              >
                <Trash2 className="size-4" /> Revoke
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function DatabaseTab({ slug, project }: { slug: string; project: ProjectDetail["project"] }) {
  return (
    <div className="space-y-5">
      <div className="grid gap-3 grid-cols-2 md:grid-cols-4">
        <StatCard label="Total storage" value={project.storage} icon={Boxes} />
        <StatCard label="Uploads" value={project.uploads} icon={Download} />
        <StatCard label="Files on disk" value={project.fileCount} icon={Copy} />
        <StatCard label="Resources" value={project.resourceCount} icon={Boxes} />
      </div>
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Collections</CardTitle>
        </CardHeader>
        <CardContent className="px-6">
          <CollectionsTable slug={slug} />
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Resources explorer</CardTitle>
        </CardHeader>
        <CardContent className="px-6">
          <ResourceExplorer slug={slug} />
        </CardContent>
      </Card>
    </div>
  );
}

function CollectionsTable({ slug }: { slug: string }) {
  const { data, isLoading } = useQuery({
    queryKey: ["project", slug, "database"],
    queryFn: () => apiFetch<{ database: { collections: { name: string; count: number }[] } }>(`/api/projects/${slug}/database`),
  });
  const collections = data?.database.collections ?? [];
  return (
    <div className="rounded-md border">
      {isLoading ? (
        <div className="p-3 space-y-2">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-7 w-full" />
          ))}
        </div>
      ) : collections.length === 0 ? (
        <div className="p-6 text-center text-xs text-muted-foreground">
          No collections yet. Create your first resource.
        </div>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Collection</TableHead>
              <TableHead>Count</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {collections.map((c) => (
              <TableRow key={c.name}>
                <TableCell className="font-mono text-xs">{c.name}</TableCell>
                <TableCell className="text-xs">{c.count}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </div>
  );
}

function UploadsTab({ slug }: { slug: string }) {
  const { data, isLoading } = useQuery({
    queryKey: ["project", slug, "files", ""],
    queryFn: () => apiFetch<{ files: { name: string; type: "file" | "dir"; size: number; modified: string }[]; subdir: string }>(`/api/projects/${slug}/files`),
  });
  const files = (data?.files ?? []).filter((f) => f.type === "file");

  return (
    <div className="space-y-3">
      <p className="text-xs text-muted-foreground">
        Cards view of the files at the project uploads root. Use the Files tab to navigate folders.
      </p>
      {isLoading ? (
        <div className="grid gap-3 grid-cols-2 md:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-28 w-full" />
          ))}
        </div>
      ) : files.length === 0 ? (
        <div className="rounded-md border p-8 text-center text-xs text-muted-foreground">
          No files uploaded yet.
        </div>
      ) : (
        <div className="grid gap-3 grid-cols-2 md:grid-cols-4">
          {files.map((f) => (
            <Card key={f.name}>
              <CardContent className="p-4 space-y-1">
                <div className="flex items-start justify-between gap-2">
                  <span className="text-xs font-medium truncate" title={f.name}>
                    {f.name}
                  </span>
                  <CopyButton
                    value={`/api/public/${slug}/${f.name}`}
                    size="icon"
                  />
                </div>
                <div className="text-[11px] text-muted-foreground">
                  {(f.size / 1024).toFixed(1)} KB
                </div>
                <div className="text-[11px] text-muted-foreground">
                  {f.modified ? relativeTime(f.modified) : "—"}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

function LogsTab({ slug }: { slug: string }) {
  const { data, isLoading } = useQuery<{ logs: ApiLogEntry[]; total: number }>({
    queryKey: ["project", slug, "logs"],
    queryFn: () =>
      apiFetch<{ logs: ApiLogEntry[]; total: number }>(
        `/api/projects/${slug}/logs?limit=100`,
      ),
  });
  const logs = data?.logs ?? [];
  return (
    <Card>
      <CardContent className="px-6 pb-4 pt-2">
        {isLoading ? (
          <div className="space-y-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-8 w-full" />
            ))}
          </div>
        ) : logs.length === 0 ? (
          <div className="p-6 text-center text-xs text-muted-foreground">
            No API requests for this project yet.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Time</TableHead>
                <TableHead>Method</TableHead>
                <TableHead>Endpoint</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>IP</TableHead>
                <TableHead>Response</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {logs.map((l) => (
                <TableRow key={l.id}>
                  <TableCell className="text-xs text-muted-foreground">
                    {formatDate(l.createdAt)}
                  </TableCell>
                  <TableCell>
                    <MethodBadge method={l.method} />
                  </TableCell>
                  <TableCell className="font-mono text-xs">{l.endpoint}</TableCell>
                  <TableCell>
                    <HttpBadge status={l.status} />
                  </TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground">
                    {l.ip ?? "—"}
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {l.responseMs != null ? `${l.responseMs}ms` : "—"}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}

function BackupTab({ slug, projectName }: { slug: string; projectName: string }) {
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery<{ backups: BackupEntry[] }>({
    queryKey: ["project", slug, "backups"],
    queryFn: () =>
      apiFetch<{ backups: BackupEntry[] }>(`/api/projects/${slug}/backup`, {
        method: "POST",
      }),
  });

  const backups = data?.backups ?? [];

  async function restoreDisabled() {
    toast.info("Restore is coming soon");
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-sm">
            Backups are ZIP archives containing the project database export and the uploads directory.
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Each backup is also saved to disk in the project storage.
          </p>
        </div>
        <Button size="sm" asChild>
          <a href={`/api/projects/${slug}/backup`} onClick={() => {
            // give the table a refresh after a download is initiated
            setTimeout(() => queryClient.invalidateQueries({ queryKey: ["project", slug, "backups"] }), 1000);
          }}>
            <Download className="size-4" />
            Create backup
          </a>
        </Button>
      </div>
      <Card>
        <CardContent className="px-6 pb-4 pt-2">
          {isLoading ? (
            <div className="space-y-2">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-8 w-full" />
              ))}
            </div>
          ) : backups.length === 0 ? (
            <div className="p-6 text-center text-xs text-muted-foreground">
              No backups yet. Click &quot;Create backup&quot; to generate one.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Filename</TableHead>
                  <TableHead>Size</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="text-right">Restore</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {backups.map((b) => (
                  <TableRow key={b.id}>
                    <TableCell className="font-mono text-xs">{b.filename}</TableCell>
                    <TableCell className="text-xs">
                      {(b.sizeBytes / 1024).toFixed(1)} KB
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {relativeTime(b.createdAt)}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button size="sm" variant="outline" disabled onClick={restoreDisabled} title="Coming soon">
                        <RefreshCw className="size-4" />
                        Restore
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
      <p className="text-[11px] text-muted-foreground">
        Tip: each project backup also bumps the Backup counter on the Security page.
      </p>
    </div>
  );
}

type BackupEntry = {
  id: string;
  filename: string;
  sizeBytes: number;
  createdAt: string;
};

function SettingsTab({
  slug,
  project,
  onDelete,
}: {
  slug: string;
  project: ProjectDetail["project"];
  onDelete: () => void;
}) {
  const queryClient = useQueryClient();
  const [name, setName] = React.useState(project.name);
  const [description, setDescription] = React.useState(project.description ?? "");
  const [version, setVersion] = React.useState(project.version);
  const [rateLimit, setRateLimit] = React.useState(project.rateLimit);
  const [allowedMimes, setAllowedMimes] = React.useState(project.settings.allowedMimes ?? "image/jpeg,image/png,image/webp,application/pdf,text/plain");
  const [maxUploadMb, setMaxUploadMb] = React.useState(project.settings.maxUploadMb ?? "10");
  const [saving, setSaving] = React.useState(false);

  // re-hydrate when project changes
  React.useEffect(() => {
    setName(project.name);
    setDescription(project.description ?? "");
    setVersion(project.version);
    setRateLimit(project.rateLimit);
    setAllowedMimes(project.settings.allowedMimes ?? "image/jpeg,image/png,image/webp,application/pdf,text/plain");
    setMaxUploadMb(project.settings.maxUploadMb ?? "10");
  }, [project]);

  async function onSave() {
    setSaving(true);
    try {
      // Save project base fields (name, description, version, rateLimit)
      await apiFetch(`/api/projects/${slug}`, {
        method: "PATCH",
        body: JSON.stringify({ name, description, version, rateLimit }),
      });
      // Save project-scoped settings
      await apiFetch(`/api/projects/${slug}/settings`, {
        method: "PATCH",
        body: JSON.stringify({
          settings: { allowedMimes, maxUploadMb },
          rateLimit,
        }),
      });
      toast.success("Settings saved");
      queryClient.invalidateQueries({ queryKey: ["project", slug] });
    } catch (err) {
      toast.error(err instanceof ApiError ? err.message : "Could not save settings");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">General</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-3 md:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="pj-name-set">Name</Label>
              <Input id="pj-name-set" value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="pj-version-set">Version</Label>
              <Input id="pj-version-set" value={version} onChange={(e) => setVersion(e.target.value)} />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="pj-desc-set">Description</Label>
            <Textarea
              id="pj-desc-set"
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>
          <div className="grid gap-3 md:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="pj-rl-set">Rate limit (per minute)</Label>
              <Input
                id="pj-rl-set"
                type="number"
                min={1}
                max={10000}
                value={rateLimit}
                onChange={(e) => setRateLimit(Number(e.target.value) || 0)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="pj-max-up">Max upload size (MB)</Label>
              <Input
                id="pj-max-up"
                type="number"
                min={1}
                max={1024}
                value={maxUploadMb}
                onChange={(e) => setMaxUploadMb(String(e.target.value || 1))}
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="pj-mimes">Allowed MIME types</Label>
            <Textarea
              id="pj-mimes"
              rows={2}
              className="font-mono text-xs"
              value={allowedMimes}
              onChange={(e) => setAllowedMimes(e.target.value)}
              placeholder="image/jpeg,image/png,application/pdf"
            />
            <p className="text-[11px] text-muted-foreground">
              Comma-separated list. Server also enforces a hard whitelist.
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="flex items-center justify-end gap-2">
        <Button onClick={onSave} disabled={saving}>
          {saving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
          Save settings
        </Button>
      </div>

      <Card className="border-destructive/40">
        <CardHeader>
          <CardTitle className="text-sm text-destructive">Danger zone</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-xs text-muted-foreground">
            Deleting <strong>{project.name}</strong> permanently removes all files,
            resources, settings and backups. This cannot be undone.
          </p>
          <Button variant="destructive" size="sm" onClick={onDelete}>
            <Trash2 className="size-4" />
            Delete project
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
