import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSession } from '@/lib/auth'
import { apiSuccess, handleApiError, apiError } from '@/lib/api-utils'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const { slug } = await ctx.params
    const project = await db.project.findUnique({ where: { slug } })
    if (!project) return apiError('Project not found', 404)
    const limit = Math.min(Number(req.nextUrl.searchParams.get('limit') ?? '50'), 200)
    const logs = await db.apiLog.findMany({
      where: { projectId: project.id },
      orderBy: { createdAt: 'desc' },
      take: limit,
    })
    return apiSuccess({ logs, total: logs.length })
  } catch (e) {
    return handleApiError(e)
  }
}
