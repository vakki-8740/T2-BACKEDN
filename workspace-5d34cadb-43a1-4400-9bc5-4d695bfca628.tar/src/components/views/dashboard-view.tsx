"use client";

import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Activity,
  Boxes,
  FolderKanban,
  HardDrive,
  Loader2,
  ShieldCheck,
  Timer,
  Webhook,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatCard } from "@/components/ui-primitives/stat-card";
import { StatusBadge } from "@/components/ui-primitives/status-badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { apiFetch } from "@/lib/api-client";
import { useAppStore } from "@/stores/app-store";
import { relativeTime } from "@/lib/format";
import { Button } from "@/components/ui/button";

type Stats = {
  stats: {
    totalProjects: number;
    activeProjects: number;
    disabledProjects: number;
    maintenanceProjects: number;
    totalFiles: number;
    totalApiRequests: number;
    totalStorageBytes: number;
    totalStorage: string;
    databases: number;
  };
  recentProjects: {
    id: string;
    name: string;
    slug: string;
    status: "ACTIVE" | "DISABLED" | "MAINTENANCE";
    createdAt: string;
    lastActivity: string | null;
  }[];
  recentActivity: {
    id: string;
    action: string;
    message: string;
    createdAt: string;
    projectId?: string | null;
  }[];
  recentApiLogs: {
    id: string;
    method: string;
    endpoint: string;
    status: number;
    createdAt: string;
    project?: { slug: string; name: string } | null;
  }[];
};

export function DashboardView() {
  const openProject = useAppStore((s) => s.openProject);
  const { data, isLoading, isFetching, refetch } = useQuery<Stats>({
    queryKey: ["dashboard", "stats"],
    queryFn: () => apiFetch<Stats>("/api/dashboard/stats"),
    refetchInterval: 60_000,
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-semibold tracking-tight">Overview</h2>
          <p className="text-sm text-muted-foreground">
            A high-level summary of every project, its storage and API activity.
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={() => refetch()} disabled={isFetching}>
          {isFetching ? (
            <Loader2 className="size-4 animate-spin" />
          ) : (
            <Activity className="size-4" />
          )}
          Refresh
        </Button>
      </div>

      <div className="grid gap-3 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-6">
        {isLoading || !data ? (
          Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-xl" />
          ))
        ) : (
          <>
            <StatCard
              label="Total projects"
              value={data.stats.totalProjects}
              icon={FolderKanban}
              hint="Across all statuses"
            />
            <StatCard
              label="Active"
              value={data.stats.activeProjects}
              icon={ShieldCheck}
              hint="Serving traffic"
            />
            <StatCard
              label="Disabled"
              value={data.stats.disabledProjects}
              icon={Timer}
              hint="API turned off"
            />
            <StatCard
              label="Maintenance"
              value={data.stats.maintenanceProjects}
              icon={Activity}
              hint="503 returned"
            />
            <StatCard
              label="Total storage"
              value={data.stats.totalStorage}
              icon={HardDrive}
              hint={`${data.stats.totalFiles} files`}
            />
            <StatCard
              label="API requests"
              value={data.stats.totalApiRequests}
              icon={Webhook}
              hint="All projects, all time"
            />
          </>
        )}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Recent projects</CardTitle>
          </CardHeader>
          <CardContent className="px-6 pb-4">
            {isLoading || !data ? (
              <div className="space-y-2">
                {Array.from({ length: 4 }).map((_, i) => (
                  <Skeleton key={i} className="h-8 w-full" />
                ))}
              </div>
            ) : data.recentProjects.length === 0 ? (
              <EmptyRow label="No projects yet" />
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Created</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.recentProjects.map((p) => (
                    <TableRow
                      key={p.id}
                      className="cursor-pointer"
                      onClick={() => openProject(p.slug)}
                    >
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="font-medium">{p.name}</span>
                          <span className="text-[11px] font-mono text-muted-foreground">
                            {p.slug}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <StatusBadge status={p.status} />
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {relativeTime(p.createdAt)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Recent activity</CardTitle>
          </CardHeader>
          <CardContent className="px-6 pb-4">
            {isLoading || !data ? (
              <div className="space-y-2">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Skeleton key={i} className="h-8 w-full" />
                ))}
              </div>
            ) : data.recentActivity.length === 0 ? (
              <EmptyRow label="No activity yet" />
            ) : (
              <ul className="divide-y">
                {data.recentActivity.map((a) => (
                  <li key={a.id} className="py-2 flex flex-col gap-0.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] font-mono text-muted-foreground uppercase tracking-wide">
                        {a.action}
                      </span>
                      <span className="text-[11px] text-muted-foreground">
                        {relativeTime(a.createdAt)}
                      </span>
                    </div>
                    <p className="text-sm">{a.message}</p>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Recent API logs</CardTitle>
        </CardHeader>
        <CardContent className="px-6 pb-4">
          {isLoading || !data ? (
            <div className="space-y-2">
              {Array.from({ length: 5 }).map((_, i) => (
                <Skeleton key={i} className="h-8 w-full" />
              ))}
            </div>
          ) : data.recentApiLogs.length === 0 ? (
            <EmptyRow label="No API requests yet" />
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Method</TableHead>
                  <TableHead>Endpoint</TableHead>
                  <TableHead>Project</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>When</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
              {data.recentApiLogs.map((l) => (
                <TableRow key={l.id}>
                  <TableCell>
                    <MethodInline method={l.method} />
                  </TableCell>
                  <TableCell className="font-mono text-xs">
                    {l.endpoint}
                  </TableCell>
                  <TableCell className="text-xs">
                    {l.project?.slug ?? "—"}
                  </TableCell>
                  <TableCell>
                    <StatusInline status={l.status} />
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {relativeTime(l.createdAt)}
                  </TableCell>
                </TableRow>
              ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function EmptyRow({ label }: { label: string }) {
  return (
    <div className="flex h-20 items-center justify-center text-xs text-muted-foreground">
      <span className="flex items-center gap-2">
        <Boxes className="size-4" />
        {label}
      </span>
    </div>
  );
}

function MethodInline({ method }: { method: string }) {
  const cls =
    method === "GET"
      ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300"
      : method === "POST"
        ? "bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300"
        : method === "DELETE"
          ? "bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300"
          : "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300";
  return (
    <span className={`rounded px-1.5 py-0.5 font-mono text-[11px] font-medium ${cls}`}>
      {method}
    </span>
  );
}

function StatusInline({ status }: { status: number }) {
  let cls = "bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300";
  if (status >= 500) cls = "bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300";
  else if (status >= 400) cls = "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300";
  return (
    <span className={`rounded px-1.5 py-0.5 font-mono text-[11px] font-medium ${cls}`}>
      {status}
    </span>
  );
}
