"use client";

import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Activity,
  Loader2,
  ScrollText,
  Server,
  Webhook,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { apiFetch } from "@/lib/api-client";
import { formatDate, relativeTime } from "@/lib/format";
import { MethodBadge, HttpBadge } from "@/components/ui-primitives/status-badge";

type ActivityEntry = {
  id: string;
  action: string;
  message: string;
  ip?: string;
  createdAt: string;
  projectId?: string | null;
};

type ApiEntry = {
  id: string;
  method: string;
  endpoint: string;
  status: number;
  ip?: string;
  responseMs?: number;
  createdAt: string;
  project?: { slug: string; name: string } | null;
};

type SystemEntry = {
  id: string;
  level?: string;
  category?: string;
  message: string;
  createdAt: string;
};

export function LogsView() {
  const [tab, setTab] = React.useState<"activity" | "api" | "system">("activity");
  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-semibold tracking-tight">Logs</h2>
        <p className="text-sm text-muted-foreground">
          Activity (admin actions), API (per-project requests) and system events.
        </p>
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
        <TabsList>
          <TabsTrigger value="activity">
            <Activity className="size-4" /> Activity
          </TabsTrigger>
          <TabsTrigger value="api">
            <Webhook className="size-4" /> API
          </TabsTrigger>
          <TabsTrigger value="system">
            <ScrollText className="size-4" /> System
          </TabsTrigger>
        </TabsList>

        <TabsContent value="activity" className="pt-4">
          <ActivityTable />
        </TabsContent>
        <TabsContent value="api" className="pt-4">
          <ApiTable />
        </TabsContent>
        <TabsContent value="system" className="pt-4">
          <SystemTable />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function ActivityTable() {
  const { data, isLoading, refetch, isFetching } = useQuery<{ logs: ActivityEntry[] }>({
    queryKey: ["logs", "activity"],
    queryFn: () => apiFetch<{ logs: ActivityEntry[] }>("/api/logs?type=activity&limit=200"),
  });
  const logs = data?.logs ?? [];
  return (
    <Card>
      <CardContent className="px-6 pb-4 pt-2">
        <div className="mb-2 flex items-center justify-end">
          <button
            className="text-[11px] text-muted-foreground hover:text-foreground"
            onClick={() => refetch()}
          >
            {isFetching ? (
              <Loader2 className="inline size-3 mr-1 animate-spin" />
            ) : null}
            Refresh
          </button>
        </div>
        {isLoading ? (
          <Skeletons />
        ) : logs.length === 0 ? (
          <Empty label="No activity yet" />
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Timestamp</TableHead>
                <TableHead>Action</TableHead>
                <TableHead>Message</TableHead>
                <TableHead>IP</TableHead>
                <TableHead>When</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {logs.map((l) => (
                <TableRow key={l.id}>
                  <TableCell className="text-xs text-muted-foreground font-mono">
                    {formatDate(l.createdAt)}
                  </TableCell>
                  <TableCell>
                    <span className="text-[11px] font-mono uppercase tracking-wide text-muted-foreground">
                      {l.action}
                    </span>
                  </TableCell>
                  <TableCell className="text-sm">{l.message}</TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground">
                    {l.ip ?? "—"}
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {relativeTime(l.createdAt)}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}

function ApiTable() {
  const { data, isLoading, refetch, isFetching } = useQuery<{ logs: ApiEntry[] }>({
    queryKey: ["logs", "api"],
    queryFn: () => apiFetch<{ logs: ApiEntry[] }>("/api/logs?type=api&limit=200"),
  });
  const logs = data?.logs ?? [];
  return (
    <Card>
      <CardContent className="px-6 pb-4 pt-2">
        <div className="mb-2 flex items-center justify-end">
          <button
            className="text-[11px] text-muted-foreground hover:text-foreground"
            onClick={() => refetch()}
          >
            {isFetching ? (
              <Loader2 className="inline size-3 mr-1 animate-spin" />
            ) : null}
            Refresh
          </button>
        </div>
        {isLoading ? (
          <Skeletons />
        ) : logs.length === 0 ? (
          <Empty label="No API requests yet" />
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Time</TableHead>
                <TableHead>Method</TableHead>
                <TableHead>Endpoint</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Project</TableHead>
                <TableHead>IP</TableHead>
                <TableHead>Response</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {logs.map((l) => (
                <TableRow key={l.id}>
                  <TableCell className="text-xs text-muted-foreground font-mono">
                    {formatDate(l.createdAt)}
                  </TableCell>
                  <TableCell>
                    <MethodBadge method={l.method} />
                  </TableCell>
                  <TableCell className="font-mono text-xs">{l.endpoint}</TableCell>
                  <TableCell>
                    <HttpBadge status={l.status} />
                  </TableCell>
                  <TableCell className="text-xs">
                    {l.project?.slug ?? "—"}
                  </TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground">
                    {l.ip ?? "—"}
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {l.responseMs != null ? `${l.responseMs}ms` : "—"}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}

function SystemTable() {
  const { data, isLoading, refetch, isFetching } = useQuery<{
    systemLogs: SystemEntry[];
    apiLogs: ApiEntry[];
  }>({
    queryKey: ["logs", "system"],
    queryFn: () =>
      apiFetch<{ systemLogs: SystemEntry[]; apiLogs: ApiEntry[] }>(
        "/api/logs?type=system&limit=200",
      ),
  });
  const sys = data?.systemLogs ?? [];
  const api = data?.apiLogs ?? [];
  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="px-6 pb-4 pt-2">
          <div className="mb-2 flex items-center justify-between">
            <h3 className="text-sm font-medium flex items-center gap-1.5">
              <Server className="size-4" /> System events
            </h3>
            <button
              className="text-[11px] text-muted-foreground hover:text-foreground"
              onClick={() => refetch()}
            >
              {isFetching ? (
                <Loader2 className="inline size-3 mr-1 animate-spin" />
              ) : null}
              Refresh
            </button>
          </div>
          {isLoading ? (
            <Skeletons />
          ) : sys.length === 0 ? (
            <Empty label="No system events yet" />
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Time</TableHead>
                  <TableHead>Level</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Message</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sys.map((s) => (
                  <TableRow key={s.id}>
                    <TableCell className="text-xs text-muted-foreground font-mono">
                      {formatDate(s.createdAt)}
                    </TableCell>
                    <TableCell>
                      <span
                        className={`rounded px-1.5 py-0.5 text-[11px] font-mono font-medium ${
                          (s.level ?? "info").toLowerCase() === "warn"
                            ? "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300"
                            : (s.level ?? "info").toLowerCase() === "error"
                              ? "bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300"
                              : "bg-muted text-muted-foreground"
                        }`}
                      >
                        {s.level ?? "info"}
                      </span>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground uppercase">
                      {s.category ?? "—"}
                    </TableCell>
                    <TableCell className="text-sm">{s.message}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="px-6 pb-4 pt-2">
          <div className="mb-2 flex items-center justify-between">
            <h3 className="text-sm font-medium flex items-center gap-1.5">
              <Webhook className="size-4" /> API events (system view)
            </h3>
          </div>
          {isLoading ? (
            <Skeletons />
          ) : api.length === 0 ? (
            <Empty label="No API requests yet" />
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Time</TableHead>
                  <TableHead>Method</TableHead>
                  <TableHead>Endpoint</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Project</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {api.map((l) => (
                  <TableRow key={l.id}>
                    <TableCell className="text-xs text-muted-foreground font-mono">
                      {formatDate(l.createdAt)}
                    </TableCell>
                    <TableCell>
                      <MethodBadge method={l.method} />
                    </TableCell>
                    <TableCell className="font-mono text-xs">{l.endpoint}</TableCell>
                    <TableCell>
                      <HttpBadge status={l.status} />
                    </TableCell>
                    <TableCell className="text-xs">
                      {l.project?.slug ?? "—"}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function Skeletons() {
  return (
    <div className="space-y-2">
      {Array.from({ length: 6 }).map((_, i) => (
        <Skeleton key={i} className="h-9 w-full" />
      ))}
    </div>
  );
}

function Empty({ label }: { label: string }) {
  return (
    <div className="flex h-24 items-center justify-center text-xs text-muted-foreground">
      {label}
    </div>
  );
}
