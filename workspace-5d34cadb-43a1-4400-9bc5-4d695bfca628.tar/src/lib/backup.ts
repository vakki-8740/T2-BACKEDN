import { promises as fs } from 'node:fs'
import path from 'node:path'
import { ZipArchive } from 'archiver'
import { Writable } from 'node:stream'
import { db } from '@/lib/db'
import { projectStorageRoot, projectUploadsDir, BACKUPS_STORAGE, ensureStorageDirs } from '@/lib/storage'

// Build a ZIP backup of a project's storage + DB snapshot and return Buffer
export async function buildProjectBackupZip(projectId: string, slug: string): Promise<{ buffer: Buffer; sizeBytes: number }> {
  await ensureStorageDirs()
  const chunks: Buffer[] = []
  const writable = new Writable({
    write(chunk, _enc, cb) {
      chunks.push(chunk)
      cb()
    },
  })
  const archive = new ZipArchive({ zlib: { level: 6 } })
  archive.pipe(writable)

  // 1) project storage (uploads + config)
  const storageRoot = projectStorageRoot(slug)
  try {
    const stat = await fs.stat(storageRoot)
    if (stat.isDirectory()) {
      archive.directory(storageRoot, 'storage', { name: 'storage' })
    }
  } catch {
    // no storage yet — skip
  }

  // 2) database snapshot (resources + files + settings + meta) as JSON
  const [resources, files, settings] = await Promise.all([
    db.projectResource.findMany({ where: { projectId } }),
    db.projectFile.findMany({ where: { projectId } }),
    db.projectSetting.findMany({ where: { projectId } }),
  ])
  const project = await db.project.findUnique({ where: { id: projectId } })
  const snapshot = {
    exportedAt: new Date().toISOString(),
    project: project
      ? {
          name: project.name,
          slug: project.slug,
          description: project.description,
          status: project.status,
          version: project.version,
          apiEnabled: project.apiEnabled,
          rateLimit: project.rateLimit,
          createdAt: project.createdAt,
        }
      : null,
    settings,
    files,
    resources,
  }
  archive.append(JSON.stringify(snapshot, null, 2), { name: 'database-snapshot.json' })
  archive.append(
    JSON.stringify({ version: 1, createdAt: new Date().toISOString(), note: 'Project Backend Manager backup' }, null, 2),
    { name: 'manifest.json' },
  )

  await archive.finalize()
  const buffer = Buffer.concat(chunks)
  return { buffer, sizeBytes: buffer.byteLength }
}

export async function saveBackupToDisk(projectId: string, slug: string, buffer: Buffer): Promise<string> {
  await ensureStorageDirs()
  const dir = path.join(BACKUPS_STORAGE, slug)
  await fs.mkdir(dir, { recursive: true })
  const stamp = new Date().toISOString().replace(/[:.]/g, '-')
  const filename = `project-${slug}-backup-${stamp}.zip`
  const full = path.join(dir, filename)
  await fs.writeFile(full, buffer)
  return filename
}

export function publicApiUrl(slug: string, sub: string = '') {
  const base = `/api/public/${slug}`
  return sub ? `${base}/${sub.replace(/^\/+/, '')}` : `${base}/`
}
