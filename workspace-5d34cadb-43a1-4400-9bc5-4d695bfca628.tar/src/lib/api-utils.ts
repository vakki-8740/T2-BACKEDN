import { NextResponse } from 'next/server'

export function jsonOk(data: unknown, status = 200) {
  return NextResponse.json({ success: true, data }, { status })
}

export function jsonError(message: string, status = 400, extra: Record<string, unknown> = {}) {
  return NextResponse.json({ success: false, message, ...extra }, { status })
}

export function apiSuccess(data: unknown, status = 200) {
  return NextResponse.json({ success: true, data }, { status })
}

export function apiError(message: string, status = 400, extra: Record<string, unknown> = {}) {
  return NextResponse.json({ success: false, message, ...extra }, { status })
}

export function handleApiError(err: unknown) {
  const e = err as Error & { status?: number }
  if (e.status === 401) return apiError('Unauthorized', 401)
  if (e.status === 403) return apiError('Forbidden or invalid CSRF token', 403)
  if (e.status === 404) return apiError('Not found', 404)
  console.error('[api error]', err)
  const msg = process.env.NODE_ENV === 'production' ? 'Internal server error' : e.message
  return apiError(msg, e.status ?? 500)
}
