"use client";

import * as React from "react";
import { useTheme } from "next-themes";
import { Moon, Sun, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  DesktopSidebar,
  SidebarNav,
  SidebarBranding,
  SidebarFooter,
} from "@/components/layout/sidebar";
import { useAppStore, type ViewKey } from "@/stores/app-store";
import { cn } from "@/lib/utils";

const TITLE_MAP: Record<ViewKey, string> = {
  dashboard: "Dashboard",
  projects: "Projects",
  project: "Project details",
  security: "Security",
  logs: "Logs",
  settings: "Settings",
};

export function Topbar({ adminEmail }: { adminEmail?: string | null }) {
  const { theme, setTheme } = useTheme();
  const view = useAppStore((s) => s.view);
  const selectedProjectSlug = useAppStore((s) => s.selectedProjectSlug);
  const [mobileOpen, setMobileOpen] = React.useState(false);

  const title = view === "project" && selectedProjectSlug ? `Project · ${selectedProjectSlug}` : TITLE_MAP[view];

  const initials = (adminEmail ?? "A").slice(0, 2).toUpperCase();

  return (
    <header className="sticky top-0 z-30 border-b bg-background/80 backdrop-blur">
      <div className="flex h-14 items-center gap-3 px-4 md:px-6">
        {/* Mobile sidebar trigger */}
        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="md:hidden" aria-label="Open menu">
              <Menu className="size-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-72 p-0">
            <SheetTitle className="sr-only">Navigation</SheetTitle>
            <div className="flex h-full flex-col">
              <div className="p-4 border-b">
                <SidebarBranding />
              </div>
              <div className="flex flex-1 flex-col gap-1 p-3">
                <SidebarNav onNavigate={() => setMobileOpen(false)} />
              </div>
              <div className="border-t p-3">
                <SidebarFooter />
              </div>
            </div>
          </SheetContent>
        </Sheet>

        <div className="flex-1 min-w-0">
          <h1 className="text-base md:text-lg font-semibold truncate">{title}</h1>
        </div>

        <Button
          variant="ghost"
          size="icon"
          aria-label="Toggle theme"
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
        >
          <Sun className="size-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
          <Moon className="absolute size-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
        </Button>

        <div className="flex items-center gap-2">
          <Avatar className="size-8 border">
            <AvatarFallback className="bg-muted text-[11px] font-semibold">
              {initials}
            </AvatarFallback>
          </Avatar>
          <div className="hidden sm:flex flex-col leading-tight">
            <span className="text-xs font-medium truncate max-w-[180px]">
              {adminEmail ?? "—"}
            </span>
            <span className="text-[11px] text-muted-foreground">Administrator</span>
          </div>
        </div>
      </div>
    </header>
  );
}

export function AppShell({
  children,
  systemName,
  adminEmail,
}: {
  children: React.ReactNode;
  systemName?: string;
  adminEmail?: string | null;
}) {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <div className="flex flex-1 min-h-0">
        <DesktopSidebar systemName={systemName} />
        <div className="flex flex-1 flex-col min-w-0">
          <Topbar adminEmail={adminEmail} />
          <main className={cn("flex-1 overflow-y-auto p-4 md:p-8")}>
            {children}
          </main>
        </div>
      </div>
      <AppFooter />
    </div>
  );
}

export function AppFooter() {
  const year = new Date().getFullYear();
  return (
    <footer className="mt-auto border-t bg-muted/40">
      <div className="px-4 md:px-6 py-3 text-xs text-muted-foreground flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1">
        <span>Project Backend Manager · v1.0 · {year}</span>
        <span className="hidden sm:inline">
          Built with Next.js 16, Prisma &amp; shadcn/ui
        </span>
      </div>
    </footer>
  );
}
