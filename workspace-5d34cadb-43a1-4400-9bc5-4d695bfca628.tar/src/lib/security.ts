import crypto from 'node:crypto'

const SLUG_RE = /^[a-z0-9][a-z0-9-]{1,62}[a-z0-9]$/

export function isValidSlug(slug: string): boolean {
  return SLUG_RE.test(slug)
}

export function sanitizeSlug(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .replace(/-{2,}/g, '-')
    .slice(0, 64)
}

const RESERVED = new Set([
  'admin', 'includes', 'assets', 'storage', 'projects', 'api', 'public',
  'login', 'logout', 'setup', 'index', 'config', 'new', 'create', 'edit',
  'delete', 'settings', 'logs', 'dashboard', 'system', 'static',
])

export function isReservedSlug(slug: string): boolean {
  return RESERVED.has(slug.toLowerCase())
}

// Path traversal protection
export function isSafeRelativePath(p: string): boolean {
  if (!p) return false
  if (path.isAbsolute(p)) return false
  const norm = path.normalize(p).replace(/\\/g, '/')
  if (norm.startsWith('..')) return false
  if (norm.includes('../') || norm.includes('/..')) return false
  if (norm.startsWith('/')) return false
  return true
}

import path from 'node:path'

export function randomToken(bytes = 24): string {
  return crypto.randomBytes(bytes).toString('hex')
}

export function randomFilename(original: string): string {
  const ext = path.extname(original).toLowerCase()
  return randomToken(16) + ext
}

export function maskKey(key: string): string {
  if (key.length <= 8) return '****'
  return key.slice(0, 4) + '…' + key.slice(-4)
}
