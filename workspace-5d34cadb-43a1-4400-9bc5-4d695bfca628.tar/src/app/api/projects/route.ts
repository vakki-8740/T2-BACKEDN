import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSession, requireCsrf, getClientIp } from '@/lib/auth'
import { apiSuccess, handleApiError, apiError } from '@/lib/api-utils'
import { sanitizeSlug, isValidSlug, isReservedSlug, randomToken } from '@/lib/security'
import { initProjectStorage, dirSizeBytes, formatBytes, projectStorageRoot, projectUploadsDir } from '@/lib/storage'
import { logActivity, logSystem } from '@/lib/logger'
import { publicApiUrl } from '@/lib/backup'
import bcrypt from 'bcryptjs'
import { z } from 'zod'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const createBody = z.object({
  name: z.string().min(2).max(80),
  slug: z.string().min(2).max(64).optional(),
  description: z.string().min(0).max(2000).default(''),
  generateApiKey: z.boolean().default(true),
  apiEnabled: z.boolean().default(true),
  rateLimit: z.number().int().min(1).max(10000).default(100),
})

export async function GET(req: NextRequest) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const search = req.nextUrl.searchParams.get('q') ?? ''
    const where = search
      ? {
          OR: [
            { name: { contains: search } },
            { slug: { contains: search } },
            { description: { contains: search } },
          ],
        }
      : {}
    const projects = await db.project.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    })
    const enriched = await Promise.all(
      projects.map(async (p) => {
        const storageBytes = await dirSizeBytes(projectStorageRoot(p.slug))
        const uploadsBytes = await dirSizeBytes(projectUploadsDir(p.slug))
        const fileCount = await db.projectFile.count({ where: { projectId: p.id } })
        const resourceCount = await db.projectResource.count({ where: { projectId: p.id } })
        return {
          id: p.id,
          name: p.name,
          slug: p.slug,
          description: p.description,
          status: p.status,
          version: p.version,
          apiEnabled: p.apiEnabled,
          rateLimit: p.rateLimit,
          apiKeyHint: p.apiKeyHint,
          hasApiKey: !!p.apiKeyHash,
          apiUrl: publicApiUrl(p.slug),
          storageBytes,
          storage: formatBytes(storageBytes),
          uploadsBytes,
          uploads: formatBytes(uploadsBytes),
          fileCount,
          resourceCount,
          createdAt: p.createdAt,
          updatedAt: p.updatedAt,
          lastActivity: p.lastActivity,
        }
      }),
    )
    return apiSuccess({ projects: enriched })
  } catch (e) {
    return handleApiError(e)
  }
}

export async function POST(req: NextRequest) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const json = await req.json().catch(() => null)
    const parsed = createBody.safeParse(json)
    if (!parsed.success) {
      return apiError('Invalid input. Please check the form fields.', 400, { issues: parsed.error.issues })
    }
    const { name, slug: rawSlug, description, generateApiKey, apiEnabled, rateLimit } = parsed.data
    const slug = sanitizeSlug(rawSlug ?? name)
    if (!isValidSlug(slug)) {
      return apiError('Invalid project slug. Use lowercase letters, numbers, and hyphens (2-64 chars).', 400)
    }
    if (isReservedSlug(slug)) {
      return apiError('This slug is reserved. Please choose another.', 400)
    }
    const existing = await db.project.findUnique({ where: { slug } })
    if (existing) {
      return apiError('A project with this slug already exists.', 409)
    }
    let apiKey: string | null = null
    let apiKeyHash: string | null = null
    let apiKeyHint: string | null = null
    if (generateApiKey) {
      apiKey = `pb_${slug}_${randomToken(20)}`
      apiKeyHash = await bcrypt.hash(apiKey, 10)
      apiKeyHint = apiKey.slice(-4)
    }
    const project = await db.project.create({
      data: {
        name,
        slug,
        description,
        status: 'ACTIVE',
        apiEnabled,
        rateLimit,
        apiKeyHash,
        apiKeyHint,
        storagePath: projectStorageRoot(slug),
      },
    })
    await initProjectStorage(slug)
    // default project settings
    await db.projectSetting.createMany({
      data: [
        { projectId: project.id, key: 'allowedMimes', value: 'image/jpeg,image/png,image/webp,application/pdf,text/plain' },
        { projectId: project.id, key: 'maxUploadMb', value: '10' },
      ],
    })
    await logActivity({
      action: 'project.create',
      projectId: project.id,
      message: `Project "${name}" (${slug}) created`,
      ip: getClientIp(req),
      userAgent: req.headers.get('user-agent') ?? undefined,
    })
    await logSystem({ category: 'system', message: `Project created: ${slug}` })
    return apiSuccess(
      {
        id: project.id,
        name,
        slug,
        status: project.status,
        apiUrl: publicApiUrl(slug),
        apiKey: apiKey, // returned ONCE for the admin to copy
        apiKeyHint,
        apiEnabled,
      },
      201,
    )
  } catch (e) {
    return handleApiError(e)
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    const csrf = req.headers.get('x-pbm-csrf') ?? undefined
    requireCsrf(sess.csrf, csrf)
    const body = await req.json().catch(() => ({}))
    const projectId = (body as { projectId?: string })?.projectId
    if (!projectId) return apiError('projectId is required', 400)
    const project = await db.project.findUnique({ where: { id: projectId } })
    if (!project) return apiError('Project not found', 404)
    await db.project.delete({ where: { id: projectId } })
    // delete storage (with safety check inside)
    const { removeProjectStorage } = await import('@/lib/storage')
    await removeProjectStorage(project.slug).catch(() => {})
    await logActivity({
      action: 'project.delete',
      message: `Project "${project.name}" (${project.slug}) deleted`,
      ip: getClientIp(req),
      userAgent: req.headers.get('user-agent') ?? undefined,
    })
    await logSystem({ category: 'system', level: 'warn', message: `Project deleted: ${project.slug}` })
    return apiSuccess({ deleted: true })
  } catch (e) {
    return handleApiError(e)
  }
}
