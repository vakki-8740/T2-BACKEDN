"use client";

import * as React from "react";
import { Boxes, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { ApiError, apiFetch } from "@/lib/api-client";
import { toast } from "sonner";

type SetupResponse = {
  setupRequired: boolean;
  admin?: { email: string; name: string } | null;
};

export function SetupScreen({ onDone }: { onDone: () => void | Promise<void> }) {
  const [email, setEmail] = React.useState("");
  const [name, setName] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [confirm, setConfirm] = React.useState("");
  const [systemName, setSystemName] = React.useState("Project Backend Manager");
  const [submitting, setSubmitting] = React.useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (submitting) return;
    if (!email || !name || !password) {
      toast.error("Please fill in all required fields");
      return;
    }
    if (password.length < 8) {
      toast.error("Password must be at least 8 characters");
      return;
    }
    if (password !== confirm) {
      toast.error("Passwords do not match");
      return;
    }
    setSubmitting(true);
    try {
      await apiFetch("/api/setup", {
        method: "POST",
        body: JSON.stringify({ email, name, password, systemName }),
      });
      toast.success("Admin account created. You can now sign in.");
      await onDone();
    } catch (err) {
      const msg = err instanceof ApiError ? err.message : "Setup failed";
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <div className="flex-1 grid lg:grid-cols-2">
        <div className="hidden lg:flex flex-col justify-between p-12 bg-secondary/40">
          <div className="flex items-center gap-2">
            <div className="flex size-9 items-center justify-center rounded-md bg-primary text-primary-foreground">
              <Boxes className="size-5" />
            </div>
            <span className="text-lg font-semibold">Project Backend Manager</span>
          </div>
          <div className="space-y-3">
            <h2 className="text-2xl font-semibold tracking-tight">
              One dashboard for every backend project.
            </h2>
            <p className="text-sm text-muted-foreground max-w-md">
              Spin up isolated project APIs, file storage and per-project
              databases in seconds. Each project gets its own API key,
              rate limits and backups.
            </p>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-center gap-2"><ShieldCheck className="size-4" /> HMAC-signed sessions with CSRF protection</li>
              <li className="flex items-center gap-2"><ShieldCheck className="size-4" /> bcrypt-hashed API keys per project</li>
              <li className="flex items-center gap-2"><ShieldCheck className="size-4" /> Sandboxed file uploads with MIME + size checks</li>
            </ul>
          </div>
          <div className="text-xs text-muted-foreground">v1.0 · © {new Date().getFullYear()}</div>
        </div>
        <div className="flex items-center justify-center p-6 md:p-10">
          <Card className="w-full max-w-md shadow-sm">
            <CardHeader>
              <CardTitle>Create the admin account</CardTitle>
              <CardDescription>
                This is a one-time setup. After creating the admin account you will be able to sign in.
              </CardDescription>
            </CardHeader>
            <form onSubmit={onSubmit}>
              <CardContent className="space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    autoComplete="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="admin@example.com"
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="name">Full name</Label>
                  <Input
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ada Lovelace"
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    autoComplete="new-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="At least 8 characters"
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="confirm">Confirm password</Label>
                  <Input
                    id="confirm"
                    type="password"
                    autoComplete="new-password"
                    value={confirm}
                    onChange={(e) => setConfirm(e.target.value)}
                    placeholder="Re-enter password"
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="systemName">System name</Label>
                  <Input
                    id="systemName"
                    value={systemName}
                    onChange={(e) => setSystemName(e.target.value)}
                    placeholder="Project Backend Manager"
                  />
                </div>
              </CardContent>
              <CardFooter className="justify-end gap-2">
                <Button type="submit" disabled={submitting}>
                  {submitting ? "Creating…" : "Create admin account"}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </div>
      </div>
      <footer className="border-t bg-background px-4 py-3 text-xs text-muted-foreground flex justify-between">
        <span>Project Backend Manager · v1.0 · {new Date().getFullYear()}</span>
        <span className="hidden sm:inline">Initial setup</span>
      </footer>
    </div>
  );
}

export function LoginScreen({ onDone }: { onDone: () => void | Promise<void> }) {
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (submitting) return;
    if (!email || !password) {
      toast.error("Email and password are required");
      return;
    }
    setSubmitting(true);
    try {
      await apiFetch("/api/auth/login", {
        method: "POST",
        body: JSON.stringify({ email, password }),
      });
      toast.success("Welcome back");
      await onDone();
    } catch (err) {
      const msg = err instanceof ApiError ? err.message : "Login failed";
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <div className="flex-1 flex items-center justify-center p-6 md:p-10">
        <Card className="w-full max-w-md shadow-sm">
          <CardHeader>
            <div className="flex items-center gap-2 mb-1">
              <div className="flex size-9 items-center justify-center rounded-md bg-primary text-primary-foreground">
                <Boxes className="size-5" />
              </div>
              <span className="text-lg font-semibold">Project Backend Manager</span>
            </div>
            <CardTitle>Sign in</CardTitle>
            <CardDescription>
              Use your administrator credentials to access the dashboard.
            </CardDescription>
          </CardHeader>
          <form onSubmit={onSubmit}>
            <CardContent className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="login-email">Email</Label>
                <Input
                  id="login-email"
                  type="email"
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@example.com"
                  required
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="login-password">Password</Label>
                <Input
                  id="login-password"
                  type="password"
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Your password"
                  required
                />
              </div>
            </CardContent>
            <CardFooter className="justify-end gap-2">
              <Button type="submit" disabled={submitting}>
                {submitting ? "Signing in…" : "Sign in"}
              </Button>
            </CardFooter>
          </form>
        </Card>
      </div>
      <footer className="border-t bg-background px-4 py-3 text-xs text-muted-foreground flex justify-between">
        <span>Project Backend Manager · v1.0 · {new Date().getFullYear()}</span>
        <span className="hidden sm:inline">Administrator sign-in</span>
      </footer>
    </div>
  );
}
