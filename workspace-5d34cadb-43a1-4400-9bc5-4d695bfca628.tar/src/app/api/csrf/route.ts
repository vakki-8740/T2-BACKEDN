import { getSession } from '@/lib/auth'
import { apiSuccess, handleApiError, apiError } from '@/lib/api-utils'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const sess = await getSession()
    if (!sess) return apiError('Unauthorized', 401)
    return apiSuccess({ csrf: sess.csrf })
  } catch (e) {
    return handleApiError(e)
  }
}
