"use client";

import * as React from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Pencil, Trash2, KeyRound } from "lucide-react";
import { apiFetch, ApiError } from "@/lib/api-client";
import { toast } from "sonner";
import { relativeTime, truncate } from "@/lib/format";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type Resource = {
  id: string;
  key: string;
  value: string;
  createdAt?: string;
  updatedAt?: string;
};
type ResourcesResponse = { collection: string; resources: Resource[] };
type DatabaseResponse = {
  database: {
    type: string;
    storage: string;
    storageBytes: number;
    uploads: string;
    uploadsBytes: number;
    fileCount: number;
    resourceCount: number;
    collections: { name: string; count: number }[];
    lastModified: string;
  };
};

export function ResourceExplorer({ slug }: { slug: string }) {
  const queryClient = useQueryClient();
  const [collection, setCollection] = React.useState("default");
  const [createOpen, setCreateOpen] = React.useState(false);
  const [editTarget, setEditTarget] = React.useState<Resource | null>(null);
  const [confirmDelete, setConfirmDelete] = React.useState<Resource | null>(null);

  const dbQ = useQuery<DatabaseResponse>({
    queryKey: ["project", slug, "database"],
    queryFn: () => apiFetch<DatabaseResponse>(`/api/projects/${slug}/database`),
  });

  const resQ = useQuery<ResourcesResponse>({
    queryKey: ["project", slug, "resources", collection],
    queryFn: () =>
      apiFetch<ResourcesResponse>(
        `/api/projects/${slug}/resources?collection=${encodeURIComponent(collection)}`,
      ),
  });

  function invalidateAll() {
    queryClient.invalidateQueries({ queryKey: ["project", slug, "resources", collection] });
    queryClient.invalidateQueries({ queryKey: ["project", slug, "database"] });
  }

  const collections = dbQ.data?.database.collections ?? [];
  const resources = resQ.data?.resources ?? [];

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-1.5">
          <Label>Collection</Label>
          <div className="flex items-center gap-2">
            <Select value={collection} onValueChange={setCollection}>
              <SelectTrigger className="w-[220px]">
                <SelectValue placeholder="Pick a collection" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="default">default</SelectItem>
                {collections
                  .filter((c) => c.name !== "default")
                  .map((c) => (
                    <SelectItem key={c.name} value={c.name}>
                      {c.name} ({c.count})
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
            {dbQ.isFetching ? (
              <span className="text-[11px] text-muted-foreground">Loading…</span>
            ) : null}
          </div>
        </div>
        <Button size="sm" onClick={() => setCreateOpen(true)}>
          <Plus className="size-4" />
          Add resource
        </Button>
      </div>

      <div className="rounded-lg border">
        {resQ.isLoading ? (
          <div className="p-3 space-y-2">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-8 w-full" />
            ))}
          </div>
        ) : resources.length === 0 ? (
          <div className="p-8 text-center text-xs text-muted-foreground">
            No resources in this collection yet.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Key</TableHead>
                <TableHead>Value (truncated)</TableHead>
                <TableHead>Updated</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {resources.map((r) => (
                <TableRow key={r.id}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <KeyRound className="size-3.5 text-muted-foreground" />
                      <code className="text-xs font-mono">{r.key}</code>
                    </div>
                  </TableCell>
                  <TableCell>
                    <code className="text-xs font-mono text-muted-foreground">
                      {truncate(r.value, 80)}
                    </code>
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {r.updatedAt ? relativeTime(r.updatedAt) : "—"}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="inline-flex gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-8"
                        onClick={() => setEditTarget(r)}
                      >
                        <Pencil className="size-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-8 text-destructive hover:text-destructive"
                        onClick={() => setConfirmDelete(r)}
                      >
                        <Trash2 className="size-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>

      <CreateResourceDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        slug={slug}
        collection={collection}
        onCreated={() => invalidateAll()}
      />
      <EditResourceDialog
        open={!!editTarget}
        onOpenChange={(v) => !v && setEditTarget(null)}
        slug={slug}
        resource={editTarget}
        onSaved={() => invalidateAll()}
      />
      <DeleteResourceDialog
        open={!!confirmDelete}
        onOpenChange={(v) => !v && setConfirmDelete(null)}
        slug={slug}
        resource={confirmDelete}
        onDeleted={() => invalidateAll()}
      />
    </div>
  );
}

function CreateResourceDialog({
  open,
  onOpenChange,
  slug,
  collection,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  slug: string;
  collection: string;
  onCreated: () => void;
}) {
  const [key, setKey] = React.useState("");
  const [value, setValue] = React.useState("");
  const [col, setCol] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);

  React.useEffect(() => {
    if (open) {
      setKey("");
      setValue("");
      setCol(collection);
    }
  }, [open, collection]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!key.trim() || !value) return;
    setSubmitting(true);
    try {
      await apiFetch(`/api/projects/${slug}/resources`, {
        method: "POST",
        body: JSON.stringify({ collection: col || "default", key: key.trim(), value }),
      });
      toast.success("Resource created");
      onOpenChange(false);
      onCreated();
    } catch (err) {
      toast.error(err instanceof ApiError ? err.message : "Could not create resource");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Add resource</DialogTitle>
          <DialogDescription>
            A resource is a key/value pair in the project&apos;s logical database.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={onSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="rsc-collection">Collection</Label>
            <Input
              id="rsc-collection"
              value={col}
              onChange={(e) => setCol(e.target.value)}
              placeholder="default"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="rsc-key">Key</Label>
            <Input
              id="rsc-key"
              value={key}
              onChange={(e) => setKey(e.target.value)}
              placeholder="user_42"
              className="font-mono"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="rsc-value">Value</Label>
            <Textarea
              id="rsc-value"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              rows={6}
              placeholder='{"name":"Ada"}'
              className="font-mono text-xs"
            />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={!key.trim() || !value || submitting}>
              {submitting ? "Creating…" : "Create"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function EditResourceDialog({
  open,
  onOpenChange,
  slug,
  resource,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  slug: string;
  resource: Resource | null;
  onSaved: () => void;
}) {
  const [value, setValue] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);

  React.useEffect(() => {
    setValue(resource?.value ?? "");
  }, [resource]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!resource) return;
    setSubmitting(true);
    try {
      await apiFetch(`/api/projects/${slug}/resources?id=${resource.id}`, {
        method: "PATCH",
        body: JSON.stringify({ value }),
      });
      toast.success("Resource updated");
      onOpenChange(false);
      onSaved();
    } catch (err) {
      toast.error(err instanceof ApiError ? err.message : "Could not update resource");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Edit resource</DialogTitle>
          <DialogDescription>
            Key: <code className="font-mono">{resource?.key}</code>
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={onSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="edit-value">Value</Label>
            <Textarea
              id="edit-value"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              rows={10}
              className="font-mono text-xs"
            />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={!resource || submitting}>
              {submitting ? "Saving…" : "Save"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function DeleteResourceDialog({
  open,
  onOpenChange,
  slug,
  resource,
  onDeleted,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  slug: string;
  resource: Resource | null;
  onDeleted: () => void;
}) {
  const [submitting, setSubmitting] = React.useState(false);

  async function onConfirm() {
    if (!resource) return;
    setSubmitting(true);
    try {
      await apiFetch(`/api/projects/${slug}/resources?id=${resource.id}`, {
        method: "DELETE",
      });
      toast.success("Resource deleted");
      onOpenChange(false);
      onDeleted();
    } catch (err) {
      toast.error(err instanceof ApiError ? err.message : "Could not delete resource");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Delete resource?</DialogTitle>
          <DialogDescription>
            This permanently deletes the resource <code className="font-mono">{resource?.key}</code>.
            This action cannot be undone.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            type="button"
            variant="destructive"
            disabled={!!resource && submitting}
            onClick={onConfirm}
          >
            {submitting ? "Deleting…" : "Delete"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
