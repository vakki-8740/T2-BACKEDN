"use client";

import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Boxes,
  Copy,
  ExternalLink,
  FolderKanban,
  MoreHorizontal,
  Plus,
  Search,
  Settings as SettingsIcon,
  Trash2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { StatusBadge } from "@/components/ui-primitives/status-badge";
import { CopyButton } from "@/components/ui-primitives/copy-button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { apiFetch } from "@/lib/api-client";
import { useAppStore } from "@/stores/app-store";
import { relativeTime } from "@/lib/format";
import { toast } from "sonner";
import { CreateProjectDialog } from "@/components/project/create-project-dialog";
import { ApiKeyRevealDialog } from "@/components/project/api-key-reveal-dialog";
import { DeleteProjectDialog } from "@/components/project/delete-project-dialog";

type Project = {
  id: string;
  name: string;
  slug: string;
  description?: string;
  status: "ACTIVE" | "DISABLED" | "MAINTENANCE";
  version?: string;
  apiEnabled: boolean;
  rateLimit: number;
  apiKeyHint?: string | null;
  hasApiKey: boolean;
  apiUrl: string;
  storageBytes: number;
  storage: string;
  uploadsBytes: number;
  uploads: string;
  fileCount: number;
  resourceCount: number;
  createdAt: string;
  updatedAt: string;
  lastActivity: string | null;
};

type ListResponse = { projects: Project[] };

export function ProjectsView() {
  const [query, setQuery] = React.useState("");
  const debounced = useDebounced(query, 250);
  const { data, isLoading, isFetching, refetch } = useQuery<ListResponse>({
    queryKey: ["projects", debounced],
    queryFn: () => {
      const qs = debounced ? `?q=${encodeURIComponent(debounced)}` : "";
      return apiFetch<ListResponse>(`/api/projects${qs}`);
    },
  });
  const [createOpen, setCreateOpen] = React.useState(false);
  const [revealedKey, setRevealedKey] = React.useState<string | null>(null);
  const [toDelete, setToDelete] = React.useState<Project | null>(null);

  const openProject = useAppStore((s) => s.openProject);

  const projects = data?.projects ?? [];

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-semibold tracking-tight">Projects</h2>
          <p className="text-sm text-muted-foreground">
            Each project is an isolated backend with its own API key and storage.
          </p>
        </div>
        <Button onClick={() => setCreateOpen(true)} size="sm">
          <Plus className="size-4" />
          Create project
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search by name, slug or description…"
          className="pl-9 max-w-md"
        />
      </div>

      <Card className="shadow-sm">
        {isLoading ? (
          <div className="p-4 space-y-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        ) : projects.length === 0 ? (
          <EmptyState
            hasQuery={!!debounced}
            onCreate={() => setCreateOpen(true)}
          />
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>API URL</TableHead>
                <TableHead>Storage</TableHead>
                <TableHead>Files</TableHead>
                <TableHead>Last activity</TableHead>
                <TableHead>Created</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {projects.map((p) => (
                <TableRow
                  key={p.id}
                  className="cursor-pointer"
                  onClick={() => openProject(p.slug)}
                >
                  <TableCell>
                    <div className="flex flex-col">
                      <span className="font-medium">{p.name}</span>
                      <span className="text-[11px] font-mono text-muted-foreground">
                        {p.slug}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <StatusBadge status={p.status} />
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <code className="text-[11px] font-mono text-muted-foreground truncate max-w-[200px]">
                        {p.apiUrl}
                      </code>
                      <CopyButton value={p.apiUrl} size="icon" label="Copy API URL" />
                    </div>
                  </TableCell>
                  <TableCell className="text-xs">{p.storage}</TableCell>
                  <TableCell className="text-xs">{p.fileCount}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {p.lastActivity ? relativeTime(p.lastActivity) : "—"}
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {relativeTime(p.createdAt)}
                  </TableCell>
                  <TableCell className="text-right">
                    <div
                      className="inline-flex"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="size-8">
                            <MoreHorizontal className="size-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>{p.name}</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => openProject(p.slug)}>
                            <ExternalLink className="size-4" />
                            Open
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => openProject(p.slug)}>
                            <SettingsIcon className="size-4" />
                            Settings
                          </DropdownMenuItem>
                          <DropdownMenuItem asChild>
                            <a href={`/api/projects/${p.slug}/backup`}>
                              <FolderKanban className="size-4" />
                              Backup
                            </a>
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            variant="destructive"
                            onClick={() => setToDelete(p)}
                          >
                            <Trash2 className="size-4" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Card>

      <CreateProjectDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        onCreated={(r) => {
          if (r.apiKey) setRevealedKey(r.apiKey);
          refetch();
        }}
      />

      <ApiKeyRevealDialog
        open={!!revealedKey}
        onOpenChange={(v) => {
          if (!v) setRevealedKey(null);
        }}
        value={revealedKey}
      />

      <DeleteProjectDialog
        open={!!toDelete}
        onOpenChange={(v) => !v && setToDelete(null)}
        project={toDelete ? { name: toDelete.name, slug: toDelete.slug } : null}
        onDeleted={() => {
          setToDelete(null);
          toast.success("Project removed");
          refetch();
        }}
      />
    </div>
  );
}

function EmptyState({
  hasQuery,
  onCreate,
}: {
  hasQuery: boolean;
  onCreate: () => void;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 p-12 text-center">
      <div className="flex size-12 items-center justify-center rounded-full bg-muted">
        <Boxes className="size-6 text-muted-foreground" />
      </div>
      <div className="space-y-1">
        <p className="text-sm font-medium">
          {hasQuery ? "No matching projects" : "No projects yet"}
        </p>
        <p className="text-xs text-muted-foreground max-w-sm">
          {hasQuery
            ? "Try a different search term, or clear the search."
            : "Create your first project to spin up an isolated backend with its own API key, storage and database."}
        </p>
      </div>
      {!hasQuery && (
        <Button size="sm" onClick={onCreate}>
          <Plus className="size-4" />
          Create your first project
        </Button>
      )}
    </div>
  );
}

function useDebounced<T>(value: T, delay = 250) {
  const [v, setV] = React.useState(value);
  React.useEffect(() => {
    const id = setTimeout(() => setV(value), delay);
    return () => clearTimeout(id);
  }, [value, delay]);
  return v;
}
