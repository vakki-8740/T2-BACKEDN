"use client";

import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { FolderPlus, Upload } from "lucide-react";
import { apiFetch } from "@/lib/api-client";
import { toast } from "sonner";
import { formatBytesNumber, relativeTime, truncate } from "@/lib/format";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { Skeleton } from "@/components/ui/skeleton";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { MoreHorizontal, Folder, FileIcon, Pencil, Trash2 } from "lucide-react";

type Entry = {
  name: string;
  type: "file" | "dir";
  size: number;
  modified: string;
  fileId?: string;
  originalName?: string;
  mime?: string;
};
type FilesResponse = { files: Entry[]; subdir: string };

export function FileManager({ slug }: { slug: string }) {
  const [subdir, setSubdir] = React.useState("");
  const { data, isLoading, refetch, isFetching } = useQuery<FilesResponse>({
    queryKey: ["project", slug, "files", subdir],
    queryFn: () => {
      const qs = subdir ? `?subdir=${encodeURIComponent(subdir)}` : "";
      return apiFetch<FilesResponse>(`/api/projects/${slug}/files${qs}`);
    },
  });

  const [uploadOpen, setUploadOpen] = React.useState(false);
  const [folderOpen, setFolderOpen] = React.useState(false);
  const [renameTarget, setRenameTarget] = React.useState<Entry | null>(null);

  function goInto(folderName: string) {
    const next = subdir ? `${subdir}/${folderName}` : folderName;
    setSubdir(next);
  }

  function goUp(to?: string) {
    if (!to) {
      setSubdir("");
      return;
    }
    setSubdir(to);
  }

  const crumbs = subdir ? subdir.split("/") : [];

  return (
    <div className="space-y-3">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              {subdir ? (
                <BreadcrumbLink asChild>
                  <button onClick={() => goUp()}>uploads</button>
                </BreadcrumbLink>
              ) : (
                <BreadcrumbPage>uploads</BreadcrumbPage>
              )}
            </BreadcrumbItem>
            {crumbs.map((c, i) => {
              const target = crumbs.slice(0, i + 1).join("/");
              const isLast = i === crumbs.length - 1;
              return (
                <BreadcrumbItem key={target}>
                  <BreadcrumbSeparator />
                  {isLast ? (
                    <BreadcrumbPage>{c}</BreadcrumbPage>
                  ) : (
                    <BreadcrumbLink asChild>
                      <button onClick={() => goUp(target)}>{c}</button>
                    </BreadcrumbLink>
                  )}
                </BreadcrumbItem>
              );
            })}
          </BreadcrumbList>
        </Breadcrumb>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setFolderOpen(true)}>
            <FolderPlus className="size-4" />
            New folder
          </Button>
          <Button size="sm" onClick={() => setUploadOpen(true)}>
            <Upload className="size-4" />
            Upload
          </Button>
        </div>
      </div>

      <div className="rounded-lg border">
        {isLoading ? (
          <div className="p-3 space-y-2">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-8 w-full" />
            ))}
          </div>
        ) : !data || data.files.length === 0 ? (
          <div className="p-8 text-center text-xs text-muted-foreground">
            This folder is empty.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Size</TableHead>
                <TableHead>Modified</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.files.map((f) => (
                <TableRow key={`${f.name}-${f.type}`}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {f.type === "dir" ? (
                        <Folder className="size-4 text-muted-foreground" />
                      ) : (
                        <FileIcon className="size-4 text-muted-foreground" />
                      )}
                      {f.type === "dir" ? (
                        <button
                          className="text-sm font-medium hover:underline"
                          onClick={() => goInto(f.name)}
                        >
                          {f.name}
                        </button>
                      ) : (
                        <span className="text-sm" title={f.originalName ? `Disk: ${f.name}` : undefined}>
                          {truncate(f.originalName ?? f.name, 50)}
                        </span>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground uppercase">
                    {f.type}
                  </TableCell>
                  <TableCell className="text-xs">
                    {f.type === "file" ? formatBytesNumber(f.size) : "—"}
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {f.modified ? relativeTime(f.modified) : "—"}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="inline-flex" onClick={(e) => e.stopPropagation()}>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="size-8">
                            <MoreHorizontal className="size-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          {f.type === "file" && f.fileId ? (
                            <DropdownMenuItem onClick={() => setRenameTarget(f)}>
                              <Pencil className="size-4" />
                              Rename
                            </DropdownMenuItem>
                          ) : null}
                          <DropdownMenuItem
                            variant="destructive"
                            disabled={f.type !== "file" || !f.fileId}
                            onClick={async () => {
                              if (f.type === "dir") {
                                toast.error(
                                  "Folder deletion is not supported via this route.",
                                );
                                return;
                              }
                              if (!f.fileId) {
                                toast.error("This file has no database record to delete.");
                                return;
                              }
                              if (!confirm(`Delete "${f.originalName ?? f.name}"? This cannot be undone.`)) return;
                              try {
                                await apiFetch(`/api/projects/${slug}/files/${f.fileId}`, {
                                  method: "DELETE",
                                });
                                toast.success("File deleted");
                                refetch();
                              } catch (err) {
                                toast.error(err instanceof Error ? err.message : "Delete failed");
                              }
                            }}
                          >
                            <Trash2 className="size-4" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>

      <UploadDialog
        open={uploadOpen}
        onOpenChange={setUploadOpen}
        slug={slug}
        subdir={subdir}
        onUploaded={() => refetch()}
      />
      <NewFolderDialog
        open={folderOpen}
        onOpenChange={setFolderOpen}
        slug={slug}
        subdir={subdir}
        onCreated={() => refetch()}
      />
      <RenameDialog
        open={!!renameTarget}
        onOpenChange={(v) => !v && setRenameTarget(null)}
        slug={slug}
        target={renameTarget}
        onDone={() => refetch()}
      />

      {isFetching ? (
        <p className="text-[11px] text-muted-foreground">Refreshing…</p>
      ) : null}
    </div>
  );
}

function UploadDialog({
  open,
  onOpenChange,
  slug,
  subdir,
  onUploaded,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  slug: string;
  subdir: string;
  onUploaded: () => void;
}) {
  const [file, setFile] = React.useState<File | null>(null);
  const [uploading, setUploading] = React.useState(false);

  async function onUpload(e: React.FormEvent) {
    e.preventDefault();
    if (!file) return;
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      if (subdir) fd.append("subdir", subdir);
      await apiFetch(`/api/projects/${slug}/files`, {
        method: "POST",
        body: fd,
      });
      toast.success("File uploaded");
      setFile(null);
      onOpenChange(false);
      onUploaded();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setUploading(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Upload a file</DialogTitle>
          <DialogDescription>
            Files are validated against the project&apos;s MIME-type whitelist and size limit.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={onUpload} className="space-y-4">
          <Input
            type="file"
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
          />
          {subdir && (
            <p className="text-xs text-muted-foreground">
              Uploading into <span className="font-mono">{subdir}/</span>
            </p>
          )}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={!file || uploading}>
              {uploading ? "Uploading…" : "Upload"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function NewFolderDialog({
  open,
  onOpenChange,
  slug,
  subdir,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  slug: string;
  subdir: string;
  onCreated: () => void;
}) {
  const [name, setName] = React.useState("");
  const [creating, setCreating] = React.useState(false);

  React.useEffect(() => {
    if (!open) setName("");
  }, [open]);

  async function onCreate(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    setCreating(true);
    try {
      await apiFetch(`/api/projects/${slug}/files`, {
        method: "PATCH",
        body: JSON.stringify({ action: "mkdir", name: name.trim(), subdir }),
      });
      toast.success("Folder created");
      setName("");
      onOpenChange(false);
      onCreated();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not create folder");
    } finally {
      setCreating(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>New folder</DialogTitle>
          <DialogDescription>
            Folders live under the uploads root. They are sandboxes — they cannot escape the project storage root.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={onCreate} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="folder-name">Folder name</Label>
            <Input
              id="folder-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="assets"
            />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={!name.trim() || creating}>
              {creating ? "Creating…" : "Create"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function RenameDialog({
  open,
  onOpenChange,
  slug,
  target,
  onDone,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  slug: string;
  target: Entry | null;
  onDone: () => void;
}) {
  const [name, setName] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);

  React.useEffect(() => {
    setName(target?.originalName ?? target?.name ?? "");
  }, [target]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!target || target.type !== "file" || !target.fileId) return;
    if (!name.trim() || name.trim() === (target.originalName ?? target.name)) {
      onOpenChange(false);
      return;
    }
    setSubmitting(true);
    try {
      await apiFetch(`/api/projects/${slug}/files`, {
        method: "PATCH",
        body: JSON.stringify({ action: "rename", fileId: target.fileId, newName: name.trim() }),
      });
      toast.success("File renamed");
      onOpenChange(false);
      onDone();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Rename failed");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Rename file</DialogTitle>
          <DialogDescription>
            Enter a new name for the file.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={onSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="rename-name">New name</Label>
            <Input
              id="rename-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={!target || submitting}>
              {submitting ? "Renaming…" : "Rename"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
